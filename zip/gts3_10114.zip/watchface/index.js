﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_frame_animation_1 = ''
        let normal_frame_animation_2 = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_hour = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 0,
              y: 0,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "anim",
              anim_fps: 3,
              anim_size: 6,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_2 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 0,
              y: 0,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "anim",
              anim_fps: 3,
              anim_size: 6,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 109,
              month_startY: 402,
              month_sc_array: ["count_1.png","count_2.png","count_3.png","count_4.png","count_5.png","count_6.png","count_7.png","count_8.png","count_9.png","count_10.png"],
              month_tc_array: ["count_1.png","count_2.png","count_3.png","count_4.png","count_5.png","count_6.png","count_7.png","count_8.png","count_9.png","count_10.png"],
              month_en_array: ["count_1.png","count_2.png","count_3.png","count_4.png","count_5.png","count_6.png","count_7.png","count_8.png","count_9.png","count_10.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 70,
              day_startY: 402,
              day_sc_array: ["count_1.png","count_2.png","count_3.png","count_4.png","count_5.png","count_6.png","count_7.png","count_8.png","count_9.png","count_10.png"],
              day_tc_array: ["count_1.png","count_2.png","count_3.png","count_4.png","count_5.png","count_6.png","count_7.png","count_8.png","count_9.png","count_10.png"],
              day_en_array: ["count_1.png","count_2.png","count_3.png","count_4.png","count_5.png","count_6.png","count_7.png","count_8.png","count_9.png","count_10.png"],
              day_zero: 1,
              day_space: -1,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 96,
              y: 398,
              src: 'slash.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 259,
              y: 402,
              font_array: ["count_1.png","count_2.png","count_3.png","count_4.png","count_5.png","count_6.png","count_7.png","count_8.png","count_9.png","count_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 305,
              y: 402,
              src: 'bat.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'second.png',
              minute_centerX: 194,
              minute_centerY: 222,
              minute_posX: 328,
              minute_posY: 325,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'first.png',
              hour_centerX: 194,
              hour_centerY: 222,
              hour_posX: 328,
              hour_posY: 325,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 154,
              hour_startY: 239,
              hour_array: ["wb_1.png","wb_2.png","wb_3.png","wb_4.png","wb_5.png","wb_6.png","wb_7.png","wb_8.png","wb_9.png","wb_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["count_1.png","count_2.png","count_3.png","count_4.png","count_5.png","count_6.png","count_7.png","count_8.png","count_9.png","count_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 158,
              y: 139,
              src: 'tree.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  