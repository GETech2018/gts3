﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_current_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_high_separator_img = ''
        let normal_sun_low_text_img = ''
        let normal_sun_low_separator_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: '001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 82,
              y: 398,
              src: '092.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 137,
              y: 395,
              src: '093.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 255,
              y: 404,
              font_array: ["030.png","031.png","032.png","033.png","034.png","035.png","036.png","037.png","038.png","039.png"],
              padding: false,
              h_space: 3,
              unit_sc: '090.png',
              unit_tc: '090.png',
              unit_en: '090.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 230,
              y: 403,
              src: '091.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 57,
              y: 351,
              font_array: ["040.png","041.png","042.png","043.png","044.png","045.png","046.png","047.png","048.png","049.png"],
              padding: false,
              h_space: 2,
              unit_sc: '080.png',
              unit_tc: '080.png',
              unit_en: '080.png',
              imperial_unit_sc: '080.png',
              imperial_unit_tc: '080.png',
              imperial_unit_en: '080.png',
              dot_image: '084.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 21,
              y: 347,
              src: '097.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 316,
              y: 351,
              font_array: ["040.png","041.png","042.png","043.png","044.png","045.png","046.png","047.png","048.png","049.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 266,
              y: 347,
              src: '099.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 283,
              y: 284,
              font_array: ["040.png","041.png","042.png","043.png","044.png","045.png","046.png","047.png","048.png","049.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 236,
              y: 281,
              src: '098.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 53,
              y: 284,
              font_array: ["040.png","041.png","042.png","043.png","044.png","045.png","046.png","047.png","048.png","049.png"],
              padding: false,
              h_space: 3,
              unit_sc: '083.png',
              unit_tc: '083.png',
              unit_en: '083.png',
              negative_image: '082.png',
              invalid_image: '082.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 17,
              y: 281,
              src: '096.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 214,
              y: 85,
              week_en: ["051.png","052.png","053.png","054.png","055.png","056.png","057.png"],
              week_tc: ["051.png","052.png","053.png","054.png","055.png","056.png","057.png"],
              week_sc: ["051.png","052.png","053.png","054.png","055.png","056.png","057.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 296,
              year_startY: 42,
              year_sc_array: ["040.png","041.png","042.png","043.png","044.png","045.png","046.png","047.png","048.png","049.png"],
              year_tc_array: ["040.png","041.png","042.png","043.png","044.png","045.png","046.png","047.png","048.png","049.png"],
              year_en_array: ["040.png","041.png","042.png","043.png","044.png","045.png","046.png","047.png","048.png","049.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 253,
              month_startY: 42,
              month_sc_array: ["040.png","041.png","042.png","043.png","044.png","045.png","046.png","047.png","048.png","049.png"],
              month_tc_array: ["040.png","041.png","042.png","043.png","044.png","045.png","046.png","047.png","048.png","049.png"],
              month_en_array: ["040.png","041.png","042.png","043.png","044.png","045.png","046.png","047.png","048.png","049.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 284,
              y: 42,
              src: '084.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 211,
              day_startY: 42,
              day_sc_array: ["040.png","041.png","042.png","043.png","044.png","045.png","046.png","047.png","048.png","049.png"],
              day_tc_array: ["040.png","041.png","042.png","043.png","044.png","045.png","046.png","047.png","048.png","049.png"],
              day_en_array: ["040.png","041.png","042.png","043.png","044.png","045.png","046.png","047.png","048.png","049.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 244,
              y: 42,
              src: '084.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 42,
              font_array: ["040.png","041.png","042.png","043.png","044.png","045.png","046.png","047.png","048.png","049.png"],
              padding: false,
              h_space: 2,
              dot_image: '084.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 34,
              y: 32,
              src: '094.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 41,
              y: 86,
              font_array: ["040.png","041.png","042.png","043.png","044.png","045.png","046.png","047.png","048.png","049.png"],
              padding: false,
              h_space: 2,
              dot_image: '084.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 140,
              y: 84,
              src: '095.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 56,
              hour_startY: 124,
              hour_array: ["010.png","011.png","012.png","013.png","014.png","015.png","016.png","017.png","018.png","019.png"],
              hour_zero: 1,
              hour_space: 7,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 214,
              minute_startY: 124,
              minute_array: ["010.png","011.png","012.png","013.png","014.png","015.png","016.png","017.png","018.png","019.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 342,
              second_startY: 126,
              second_array: ["020.png","021.png","022.png","023.png","024.png","025.png","026.png","027.png","028.png","029.png"],
              second_zero: 1,
              second_space: 5,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFF1E1E1E',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 56,
              hour_startY: 124,
              hour_array: ["010.png","011.png","012.png","013.png","014.png","015.png","016.png","017.png","018.png","019.png"],
              hour_zero: 1,
              hour_space: 7,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 214,
              minute_startY: 124,
              minute_array: ["010.png","011.png","012.png","013.png","014.png","015.png","016.png","017.png","018.png","019.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 337,
              y: 114,
              w: 116,
              h: 71,
              src: '102.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 0,
              w: 192,
              h: 114,
              src: '102.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 200,
              y: 1,
              w: 173,
              h: 110,
              src: '102.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: -1,
              y: 254,
              w: 192,
              h: 81,
              src: '101.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 196,
              y: 334,
              w: 195,
              h: 58,
              src: '101.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 196,
              y: 254,
              w: 194,
              h: 77,
              src: '101.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: -8,
              y: 341,
              w: 198,
              h: 53,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '101.png',
              normal_src: '101.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 198,
              y: 397,
              w: 184,
              h: 125,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '101.png',
              normal_src: '101.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 198,
              y: 121,
              w: 137,
              h: 125,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '101.png',
              normal_src: '101.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 44,
              y: 121,
              w: 137,
              h: 125,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '101.png',
              normal_src: '101.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}