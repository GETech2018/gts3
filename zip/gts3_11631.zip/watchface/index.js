﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_high_TextCircle = new Array(4);
        let normal_high_TextCircle_ASCIIARRAY = new Array(10);
        let normal_high_TextCircle_img_width = 16;
        let normal_high_TextCircle_img_height = 21;
        let normal_high_TextCircle_unit = null;
        let normal_high_TextCircle_unit_width = 13;
        let normal_high_TextCircle_dot_width = 15;
        let normal_low_TextCircle = new Array(4);
        let normal_low_TextCircle_ASCIIARRAY = new Array(10);
        let normal_low_TextCircle_img_width = 16;
        let normal_low_TextCircle_img_height = 21;
        let normal_low_TextCircle_unit = null;
        let normal_low_TextCircle_unit_width = 13;
        let normal_low_TextCircle_dot_width = 15;
        let normal_weather_image_progress_img_level = ''
        let normal_sun_icon_img = ''
        let normal_sunrise_TextCircle = new Array(5);
        let normal_sunrise_TextCircle_ASCIIARRAY = new Array(10);
        let normal_sunrise_TextCircle_img_width = 16;
        let normal_sunrise_TextCircle_img_height = 21;
        let normal_sunrise_TextCircle_dot_width = 16;
        let normal_sunset_TextCircle = new Array(5);
        let normal_sunset_TextCircle_ASCIIARRAY = new Array(10);
        let normal_sunset_TextCircle_img_width = 16;
        let normal_sunset_TextCircle_img_height = 21;
        let normal_sunset_TextCircle_dot_width = 16;
        let normal_moon_image_progress_img_level = ''
        let normal_day_TextCircle = new Array(2);
        let normal_day_TextCircle_ASCIIARRAY = new Array(10);
        let normal_day_TextCircle_img_width = 16;
        let normal_day_TextCircle_img_height = 21;
        let normal_timerTextUpdate = undefined;
        let normal_date_img_date_week_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_moon_image_progress_img_level = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'f01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 233,
              y: 10,
              image_array: ["b01.png","b02.png","b03.png","b04.png","b05.png","b06.png","b07.png","b08.png","b09.png","b10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 194,
              // center_y: 224,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 189,
              // line_width: 5,
              // line_cap: Rounded,
              // color: 0xFFFF0000,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 194,
              center_y: 224,
              start_angle: 0,
              end_angle: 360,
              radius: 187,
              line_width: 5,
              corner_flag: 0,
              color: 0xFFFF0000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 293,
              font_array: ["0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_high_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 195,
              // circle_center_Y: 225,
              // font_array: ["0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png"],
              // radius: 208,
              // angle: -126,
              // char_space_angle: 0,
              // unit: '0018.png',
              // dot_image: '0017.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.WEATHER_HIGH,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_high_TextCircle_ASCIIARRAY[0] = '0019.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[1] = '0020.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[2] = '0021.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[3] = '0022.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[4] = '0023.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[5] = '0024.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[6] = '0025.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[7] = '0026.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[8] = '0027.png';  // set of images with numbers
            normal_high_TextCircle_ASCIIARRAY[9] = '0028.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_high_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 195,
                center_y: 225,
                pos_x: 195 - normal_high_TextCircle_img_width / 2,
                pos_y: 225 + 198,
                src: '0019.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_high_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_high_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              center_x: 195,
              center_y: 225,
              pos_x: 195 - normal_high_TextCircle_unit_width / 2,
              pos_y: 225 + 198,
              src: '0018.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_high_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            // normal_low_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 195,
              // circle_center_Y: 225,
              // font_array: ["0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png"],
              // radius: 208,
              // angle: -157,
              // char_space_angle: 0,
              // unit: '0018.png',
              // dot_image: '0017.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.WEATHER_LOW,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_low_TextCircle_ASCIIARRAY[0] = '0019.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[1] = '0020.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[2] = '0021.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[3] = '0022.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[4] = '0023.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[5] = '0024.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[6] = '0025.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[7] = '0026.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[8] = '0027.png';  // set of images with numbers
            normal_low_TextCircle_ASCIIARRAY[9] = '0028.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_low_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 195,
                center_y: 225,
                pos_x: 195 - normal_low_TextCircle_img_width / 2,
                pos_y: 225 + 198,
                src: '0019.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_low_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_low_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              center_x: 195,
              center_y: 225,
              pos_x: 195 - normal_low_TextCircle_unit_width / 2,
              pos_y: 225 + 198,
              src: '0018.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_low_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 36,
              y: 368,
              image_array: ["113.png","114.png","115.png","116.png","117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png","125.png","126.png","127.png","128.png","129.png","130.png","131.png","132.png","133.png","134.png","135.png","136.png","137.png","138.png","139.png","140.png","141.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 305,
              y: 375,
              src: 's02.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_sunrise_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 195,
              // circle_center_Y: 225,
              // font_array: ["0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png"],
              // radius: 203,
              // angle: 170,
              // char_space_angle: 0,
              // dot_image: '0029.png',
              // zero: true,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.SUN_RISE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_sunrise_TextCircle_ASCIIARRAY[0] = '0019.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[1] = '0020.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[2] = '0021.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[3] = '0022.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[4] = '0023.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[5] = '0024.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[6] = '0025.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[7] = '0026.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[8] = '0027.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[9] = '0028.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_sunrise_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 195,
                center_y: 225,
                pos_x: 195 - normal_sunrise_TextCircle_img_width / 2,
                pos_y: 225 + 193,
                src: '0019.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_sunrise_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // normal_sunset_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 195,
              // circle_center_Y: 225,
              // font_array: ["0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png"],
              // radius: 203,
              // angle: 116,
              // char_space_angle: 0,
              // dot_image: '0029.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.SUN_SET,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_sunset_TextCircle_ASCIIARRAY[0] = '0019.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[1] = '0020.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[2] = '0021.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[3] = '0022.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[4] = '0023.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[5] = '0024.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[6] = '0025.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[7] = '0026.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[8] = '0027.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[9] = '0028.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_sunset_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 195,
                center_y: 225,
                pos_x: 195 - normal_sunset_TextCircle_img_width / 2,
                pos_y: 225 + 193,
                src: '0019.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_sunset_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 115,
              y: 126,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_day_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 195,
              // circle_center_Y: 231,
              // font_array: ["0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png"],
              // radius: 240,
              // angle: -36,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_day_TextCircle_ASCIIARRAY[0] = '0019.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[1] = '0020.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[2] = '0021.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[3] = '0022.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[4] = '0023.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[5] = '0024.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[6] = '0025.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[7] = '0026.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[8] = '0027.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[9] = '0028.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_day_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 195,
                center_y: 231,
                pos_x: 195 - normal_day_TextCircle_img_width / 2,
                pos_y: 231 - 250,
                src: '0019.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_day_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const timeNaw = hmSensor.createSensor(hmSensor.id.TIME);

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 24,
              y: 20,
              week_en: ["dat01.png","dat02.png","dat03.png","dat04.png","dat05.png","dat06.png","dat07.png"],
              week_tc: ["dat01.png","dat02.png","dat03.png","dat04.png","dat05.png","dat06.png","dat07.png"],
              week_sc: ["dat01.png","dat02.png","dat03.png","dat04.png","dat05.png","dat06.png","dat07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'a01.png',
              hour_centerX: 195,
              hour_centerY: 225,
              hour_posX: 34,
              hour_posY: 151,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'a02.png',
              minute_centerX: 195,
              minute_centerY: 224,
              minute_posX: 31,
              minute_posY: 171,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0071.png',
              second_centerX: 195,
              second_centerY: 224,
              second_posX: 13,
              second_posY: 180,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'bg-aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 249,
              year_startY: 300,
              year_sc_array: ["0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png"],
              year_tc_array: ["0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png"],
              year_en_array: ["0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 202,
              month_startY: 300,
              month_sc_array: ["0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png"],
              month_tc_array: ["0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png"],
              month_en_array: ["0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: '0017.png',
              month_unit_tc: '0017.png',
              month_unit_en: '0017.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 160,
              day_startY: 300,
              day_sc_array: ["0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png"],
              day_tc_array: ["0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png"],
              day_en_array: ["0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: '0017.png',
              day_unit_tc: '0017.png',
              day_unit_en: '0017.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 115,
              y: 126,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'a01.png',
              hour_centerX: 195,
              hour_centerY: 225,
              hour_posX: 34,
              hour_posY: 151,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'a02.png',
              minute_centerX: 195,
              minute_centerY: 224,
              minute_posX: 31,
              minute_posY: 171,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 150,
              y: 178,
              w: 100,
              h: 100,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 17,
              y: 16,
              w: 100,
              h: 100,
              src: '39.png',
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 272,
              y: 347,
              w: 100,
              h: 100,
              src: '39.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 24,
              y: 325,
              w: 100,
              h: 100,
              src: '39.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function text_update() {
              console.log('text_update()');
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;
              let high_temp = -100;
              if (forecastData.count > 0) {
                high_temp = forecastData.data[0].high;
              }; // end forecastData;

              console.log('update text circle high_forecastData');
              let temperatureHigh = undefined;
              let normal_high_circle_string = undefined;
              if (high_temp > -100) {
                temperatureHigh = 0;
                normal_high_circle_string = String(high_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_high_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_high_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 54;
                if (temperatureHigh != null && temperatureHigh != undefined && isFinite(temperatureHigh) && normal_high_circle_string.length > 0 && normal_high_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_high_TextCircle_img_angle = 0;
                  let normal_high_TextCircle_dot_img_angle = 0;
                  let normal_high_TextCircle_unit_angle = 0;
                  normal_high_TextCircle_img_angle = toDegree(Math.atan2(normal_high_TextCircle_img_width/2, 208));
                  normal_high_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_high_TextCircle_dot_width/2, 208));
                  normal_high_TextCircle_unit_angle = toDegree(Math.atan2(normal_high_TextCircle_unit_width/2, 208));
                  // alignment = CENTER_H
                  let normal_high_TextCircle_angleOffset = normal_high_TextCircle_img_angle * (normal_high_circle_string.length - 1);
                  normal_high_TextCircle_angleOffset = normal_high_TextCircle_angleOffset + (normal_high_TextCircle_img_angle + normal_high_TextCircle_unit_angle + 0) / 2;
                  normal_high_TextCircle_angleOffset = -normal_high_TextCircle_angleOffset;
                  char_Angle -= normal_high_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_high_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_high_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_high_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_high_TextCircle[index].setProperty(hmUI.prop.POS_X, 195 - normal_high_TextCircle_img_width / 2);
                      normal_high_TextCircle[index].setProperty(hmUI.prop.SRC, normal_high_TextCircle_ASCIIARRAY[charCode]);
                      normal_high_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_high_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle -= normal_high_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_high_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_high_TextCircle[index].setProperty(hmUI.prop.POS_X, 195 - normal_high_TextCircle_dot_width / 2);
                      normal_high_TextCircle[index].setProperty(hmUI.prop.SRC, '0017.png');
                      normal_high_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_high_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle -= normal_high_TextCircle_unit_angle;
                  normal_high_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_high_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };
              let low_temp = -100;
              if (forecastData.count > 0) {
                low_temp = forecastData.data[0].low;
              }; // end forecastData;

              console.log('update text circle low_forecastData');
              let temperatureLow = undefined;
              let normal_low_circle_string = undefined;
              if (low_temp > -100) {
                temperatureLow = 0;
                normal_low_circle_string = String(low_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_low_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_low_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 23;
                if (temperatureLow != null && temperatureLow != undefined && isFinite(temperatureLow) && normal_low_circle_string.length > 0 && normal_low_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_low_TextCircle_img_angle = 0;
                  let normal_low_TextCircle_dot_img_angle = 0;
                  let normal_low_TextCircle_unit_angle = 0;
                  normal_low_TextCircle_img_angle = toDegree(Math.atan2(normal_low_TextCircle_img_width/2, 208));
                  normal_low_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_low_TextCircle_dot_width/2, 208));
                  normal_low_TextCircle_unit_angle = toDegree(Math.atan2(normal_low_TextCircle_unit_width/2, 208));
                  // alignment = CENTER_H
                  let normal_low_TextCircle_angleOffset = normal_low_TextCircle_img_angle * (normal_low_circle_string.length - 1);
                  normal_low_TextCircle_angleOffset = normal_low_TextCircle_angleOffset + (normal_low_TextCircle_img_angle + normal_low_TextCircle_unit_angle + 0) / 2;
                  normal_low_TextCircle_angleOffset = -normal_low_TextCircle_angleOffset;
                  char_Angle -= normal_low_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_low_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_low_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_low_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_low_TextCircle[index].setProperty(hmUI.prop.POS_X, 195 - normal_low_TextCircle_img_width / 2);
                      normal_low_TextCircle[index].setProperty(hmUI.prop.SRC, normal_low_TextCircle_ASCIIARRAY[charCode]);
                      normal_low_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_low_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle -= normal_low_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_low_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_low_TextCircle[index].setProperty(hmUI.prop.POS_X, 195 - normal_low_TextCircle_dot_width / 2);
                      normal_low_TextCircle[index].setProperty(hmUI.prop.SRC, '0017.png');
                      normal_low_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_low_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle -= normal_low_TextCircle_unit_angle;
                  normal_low_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_low_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };
              let tideData = weatherData.tideData;
              let sunrise_hour = -1;
              let sunrise_minute = -1;
              if (tideData.count > 0) {
                sunrise_hour = tideData.data[0].sunrise.hour;
                sunrise_minute = tideData.data[0].sunrise.minute;
              }; // end tideData;

              console.log('update text circle sunrise_tideData');
              let sunriseTime = undefined;
              let normal_sunrise_circle_string = undefined;
              if (sunrise_hour >= 0 && sunrise_minute >= 0) {
                sunriseTime = 0;
                normal_sunrise_circle_string = String(sunrise_hour).padStart(2, '0') + '.' + String(sunrise_minute).padStart(2, '0');
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_sunrise_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 350;
                if (sunriseTime != null && sunriseTime != undefined && isFinite(sunriseTime) && normal_sunrise_circle_string.length > 0 && normal_sunrise_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_sunrise_TextCircle_img_angle = 0;
                  let normal_sunrise_TextCircle_dot_img_angle = 0;
                  normal_sunrise_TextCircle_img_angle = toDegree(Math.atan2(normal_sunrise_TextCircle_img_width/2, 203));
                  normal_sunrise_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_sunrise_TextCircle_dot_width/2, 203));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_sunrise_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_sunrise_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.POS_X, 195 - normal_sunrise_TextCircle_img_width / 2);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.SRC, normal_sunrise_TextCircle_ASCIIARRAY[charCode]);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_sunrise_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle -= normal_sunrise_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.POS_X, 195 - normal_sunrise_TextCircle_dot_width / 2);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.SRC, '0029.png');
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_sunrise_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite

              };
              let sunset_hour = -1;
              let sunset_minute = -1;
              if (tideData.count > 0) {
                sunset_hour = tideData.data[0].sunset.hour;
                sunset_minute = tideData.data[0].sunset.minute;
              }; // end tideData;

              console.log('update text circle sunset_tideData');
              let sunsetTime = undefined;
              let normal_sunset_circle_string = undefined;
              if (sunset_hour >= 0 && sunset_minute >= 0) {
                sunsetTime = 0;
                normal_sunset_circle_string = String(sunset_hour) + '.' + String(sunset_minute).padStart(2, '0');
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_sunset_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 296;
                if (sunsetTime != null && sunsetTime != undefined && isFinite(sunsetTime) && normal_sunset_circle_string.length > 0 && normal_sunset_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_sunset_TextCircle_img_angle = 0;
                  let normal_sunset_TextCircle_dot_img_angle = 0;
                  normal_sunset_TextCircle_img_angle = toDegree(Math.atan2(normal_sunset_TextCircle_img_width/2, 203));
                  normal_sunset_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_sunset_TextCircle_dot_width/2, 203));
                  // alignment = RIGHT
                  let normal_sunset_TextCircle_angleOffset = normal_sunset_TextCircle_img_angle * (normal_sunset_circle_string.length - 1);
                  normal_sunset_TextCircle_angleOffset = -normal_sunset_TextCircle_angleOffset;
                  char_Angle -= 2 * normal_sunset_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_sunset_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_sunset_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.POS_X, 195 - normal_sunset_TextCircle_img_width / 2);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.SRC, normal_sunset_TextCircle_ASCIIARRAY[charCode]);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_sunset_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle -= normal_sunset_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.POS_X, 195 - normal_sunset_TextCircle_dot_width / 2);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.SRC, '0029.png');
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_sunset_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle day_TIME');
              let valueDay = timeNaw.day;
              let normal_day_circle_string = parseInt(valueDay).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_day_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -36;
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && normal_day_circle_string.length > 0 && normal_day_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_day_TextCircle_img_angle = 0;
                  let normal_day_TextCircle_dot_img_angle = 0;
                  normal_day_TextCircle_img_angle = toDegree(Math.atan2(normal_day_TextCircle_img_width/2, 240));
                  // alignment = CENTER_H
                  let normal_day_TextCircle_angleOffset = normal_day_TextCircle_img_angle * (normal_day_circle_string.length - 1);
                  char_Angle -= normal_day_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_day_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_day_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_day_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_day_TextCircle[index].setProperty(hmUI.prop.POS_X, 195 - normal_day_TextCircle_img_width / 2);
                      normal_day_TextCircle[index].setProperty(hmUI.prop.SRC, normal_day_TextCircle_ASCIIARRAY[charCode]);
                      normal_day_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_day_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 194,
                      center_y: 224,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 187,
                      line_width: 5,
                      corner_flag: 0,
                      color: 0xFFFF0000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}