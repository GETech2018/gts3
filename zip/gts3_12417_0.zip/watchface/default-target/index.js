try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 390,
                    h: 450,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 197,
                    hour_centerY: 223,
                    hour_posX: 32,
                    hour_posY: 164,
                    hour_path: '3.png',
                    hour_cover_x: 172,
                    hour_cover_y: 200,
                    minute_centerX: 197,
                    minute_centerY: 223,
                    minute_posX: 23,
                    minute_posY: 201,
                    minute_path: '5.png',
                    minute_cover_path: '4.png',
                    minute_cover_x: 182,
                    minute_cover_y: 212,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 390,
                    h: 450,
                    src: '6.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 197,
                    hour_centerY: 223,
                    hour_posX: 32,
                    hour_posY: 164,
                    hour_path: '7.png',
                    hour_cover_x: 172,
                    hour_cover_y: 200,
                    minute_centerX: 197,
                    minute_centerY: 223,
                    minute_posX: 23,
                    minute_posY: 201,
                    minute_path: '9.png',
                    minute_cover_path: '8.png',
                    minute_cover_x: 182,
                    minute_cover_y: 212,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}