﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let editBg = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_hour_TextCircle = new Array(2);
        let normal_hour_TextCircle_ASCIIARRAY = new Array(10);
        let normal_hour_TextCircle_img_width = 19;
        let normal_hour_TextCircle_img_height = 36;
        let normal_hour_TextCircle_unit = null;
        let normal_hour_TextCircle_unit_width = 4;
        let normal_hour_TextCircle_error_img_width = 10;
        let normal_timerTextUpdate = undefined;
        let normal_minute_TextCircle = new Array(2);
        let normal_minute_TextCircle_ASCIIARRAY = new Array(10);
        let normal_minute_TextCircle_img_width = 19;
        let normal_minute_TextCircle_img_height = 36;
        let normal_minute_TextCircle_error_img_width = 10;
        let normal_digital_clock_img_time_AmPm = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_step_circle_scale = ''
        let idle_step_current_text_img = ''
        let idle_step_current_separator_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_text_separator_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_city_name_text = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_hour_TextCircle = new Array(2);
        let idle_hour_TextCircle_ASCIIARRAY = new Array(10);
        let idle_hour_TextCircle_img_width = 19;
        let idle_hour_TextCircle_img_height = 36;
        let idle_hour_TextCircle_unit = null;
        let idle_hour_TextCircle_unit_width = 4;
        let idle_hour_TextCircle_error_img_width = 10;
        let idle_timerTextUpdate = undefined;
        let idle_minute_TextCircle = new Array(2);
        let idle_minute_TextCircle_ASCIIARRAY = new Array(10);
        let idle_minute_TextCircle_img_width = 19;
        let idle_minute_TextCircle_img_height = 36;
        let idle_minute_TextCircle_error_img_width = 10;
        let idle_digital_clock_img_time_AmPm = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 390,
              // h: 450,
              // AOD_show: True,
              bg_config: [
                { id: 1, preview: 'bg_edit_1_preview1.png', path: 'bg1.png' },
                { id: 2, preview: 'bg_edit_2_preview.png', path: 'bg2.png' },
                { id: 3, preview: 'bg_edit_3_preview.png', path: 'bg3.png' },
              ],
              count: 3,
              default_id: 1,
              fg: '.png',
              tips_bg: '0099.png',
              tips_x: 173,
              tips_y: 111,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 200,
              y: 406,
              src: '0083.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 2,
              y: 139,
              src: '0084.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 94,
              y: 3,
              src: '0082.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 352,
              y: 268,
              src: '0085.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 106,
              // center_y: 344,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 100,
              // line_width: 11,
              // line_cap: Flat,
              // color: 0xFF585858,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 106,
              center_y: 344,
              start_angle: 360,
              end_angle: 0,
              radius: 95,
              line_width: 11,
              corner_flag: 3,
              color: 0xFF585858,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 46,
              y: 312,
              font_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              padding: false,
              h_space: 6,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 80,
              y: 259,
              src: '0097.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 69,
              y: 393,
              font_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              padding: false,
              h_space: 6,
              invalid_image: '0052.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 88,
              y: 361,
              src: '0096.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 6,
              y: 214,
              font_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
              padding: false,
              h_space: 4,
              unit_sc: '0021.png',
              unit_tc: '0021.png',
              unit_en: '0021.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 30,
              y: 179,
              image_array: ["0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 124,
              y: 204,
              w: 200,
              h: 50,
              text_size: 40,
              char_space: 1,
              line_space: 0,
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 270,
              y: 390,
              font_array: ["0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png"],
              padding: false,
              h_space: 6,
              unit_sc: '0020.png',
              unit_tc: '0020.png',
              unit_en: '0020.png',
              negative_image: '0017.png',
              invalid_image: '0017.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 277,
              y: 320,
              image_array: ["0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 43,
              day_startY: 85,
              day_sc_array: ["0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png"],
              day_tc_array: ["0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png"],
              day_en_array: ["0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 33,
              y: 38,
              week_en: ["0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png"],
              week_tc: ["0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png"],
              week_sc: ["0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_hour_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 224,
              // circle_center_Y: 163,
              // font_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              // radius: 112,
              // angle: -17,
              // char_space_angle: 4,
              // unit: '0019.png',
              // error_image: '0052.png',
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: false,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextCircle_ASCIIARRAY[0] = '0007.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[1] = '0008.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[2] = '0009.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[3] = '0010.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[4] = '0011.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[5] = '0012.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[6] = '0013.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[7] = '0014.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[8] = '0015.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[9] = '0016.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_hour_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 224,
                center_y: 163,
                pos_x: 224 - normal_hour_TextCircle_img_width / 2,
                pos_y: 163 - 130,
                src: '0007.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_hour_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              center_x: 224,
              center_y: 163,
              pos_x: 224 - normal_hour_TextCircle_unit_width / 2,
              pos_y: 163 - 130,
              src: '0019.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_hour_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const timeNaw = hmSensor.createSensor(hmSensor.id.TIME);
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            // normal_minute_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 224,
              // circle_center_Y: 163,
              // font_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              // radius: 112,
              // angle: 17,
              // char_space_angle: 4,
              // error_image: '0052.png',
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_minute_TextCircle_ASCIIARRAY[0] = '0007.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[1] = '0008.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[2] = '0009.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[3] = '0010.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[4] = '0011.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[5] = '0012.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[6] = '0013.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[7] = '0014.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[8] = '0015.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[9] = '0016.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_minute_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 224,
                center_y: 163,
                pos_x: 224 - normal_minute_TextCircle_img_width / 2,
                pos_y: 163 - 130,
                src: '0007.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 209,
              am_y: 76,
              am_sc_path: '0022.png',
              am_en_path: '0022.png',
              pm_x: 209,
              pm_y: 76,
              pm_sc_path: '0023.png',
              pm_en_path: '0023.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0003.png',
              hour_centerX: 224,
              hour_centerY: 163,
              hour_posX: 20,
              hour_posY: 152,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0004.png',
              minute_centerX: 224,
              minute_centerY: 163,
              minute_posX: 20,
              minute_posY: 157,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0005.png',
              second_centerX: 224,
              second_centerY: 163,
              second_posX: 20,
              second_posY: 157,
              second_cover_path: '0006.png',
              second_cover_x: 208,
              second_cover_y: 147,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 200,
              y: 406,
              src: '0083.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 2,
              y: 139,
              src: '0084.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 94,
              y: 3,
              src: '0082.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 352,
              y: 268,
              src: '0085.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 106,
              // center_y: 344,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 100,
              // line_width: 11,
              // line_cap: Flat,
              // color: 0xFF585858,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 106,
              center_y: 344,
              start_angle: 360,
              end_angle: 0,
              radius: 95,
              line_width: 11,
              corner_flag: 3,
              color: 0xFF585858,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 46,
              y: 312,
              font_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              padding: false,
              h_space: 6,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 80,
              y: 259,
              src: '0097.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 69,
              y: 393,
              font_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              padding: false,
              h_space: 6,
              invalid_image: '0052.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 88,
              y: 361,
              src: '0096.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 6,
              y: 214,
              font_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
              padding: false,
              h_space: 4,
              unit_sc: '0021.png',
              unit_tc: '0021.png',
              unit_en: '0021.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 30,
              y: 179,
              image_array: ["0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 124,
              y: 204,
              w: 200,
              h: 50,
              text_size: 40,
              char_space: 1,
              line_space: 0,
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 270,
              y: 390,
              font_array: ["0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png"],
              padding: false,
              h_space: 6,
              unit_sc: '0020.png',
              unit_tc: '0020.png',
              unit_en: '0020.png',
              negative_image: '0017.png',
              invalid_image: '0017.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 277,
              y: 320,
              image_array: ["0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 43,
              day_startY: 85,
              day_sc_array: ["0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png"],
              day_tc_array: ["0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png"],
              day_en_array: ["0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 33,
              y: 38,
              week_en: ["0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png"],
              week_tc: ["0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png"],
              week_sc: ["0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_hour_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 224,
              // circle_center_Y: 163,
              // font_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              // radius: 112,
              // angle: -17,
              // char_space_angle: 4,
              // unit: '0019.png',
              // error_image: '0052.png',
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: false,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_hour_TextCircle_ASCIIARRAY[0] = '0007.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[1] = '0008.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[2] = '0009.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[3] = '0010.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[4] = '0011.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[5] = '0012.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[6] = '0013.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[7] = '0014.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[8] = '0015.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[9] = '0016.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_hour_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 224,
                center_y: 163,
                pos_x: 224 - idle_hour_TextCircle_img_width / 2,
                pos_y: 163 - 130,
                src: '0007.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_hour_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_hour_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              center_x: 224,
              center_y: 163,
              pos_x: 224 - idle_hour_TextCircle_unit_width / 2,
              pos_y: 163 - 130,
              src: '0019.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_hour_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // idle_minute_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 224,
              // circle_center_Y: 163,
              // font_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              // radius: 112,
              // angle: 17,
              // char_space_angle: 4,
              // error_image: '0052.png',
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_minute_TextCircle_ASCIIARRAY[0] = '0007.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[1] = '0008.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[2] = '0009.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[3] = '0010.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[4] = '0011.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[5] = '0012.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[6] = '0013.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[7] = '0014.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[8] = '0015.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[9] = '0016.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_minute_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 224,
                center_y: 163,
                pos_x: 224 - idle_minute_TextCircle_img_width / 2,
                pos_y: 163 - 130,
                src: '0007.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_minute_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 209,
              am_y: 76,
              am_sc_path: '0022.png',
              am_en_path: '0022.png',
              pm_x: 209,
              pm_y: 76,
              pm_sc_path: '0023.png',
              pm_en_path: '0023.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0003.png',
              hour_centerX: 224,
              hour_centerY: 163,
              hour_posX: 20,
              hour_posY: 152,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0004.png',
              minute_centerX: 224,
              minute_centerY: 163,
              minute_posX: 20,
              minute_posY: 157,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0005.png',
              second_centerX: 224,
              second_centerY: 163,
              second_posX: 20,
              second_posY: 157,
              second_cover_path: '0006.png',
              second_cover_x: 208,
              second_cover_y: 147,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: BT Off,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: BT On,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "BT Off"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "BT On"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

           //music shortcut
            normal_img_music = hmUI.createWidget(hmUI.widget.IMG, {
              x: 80,
              y: 159,
              w: 75,
              h: 75,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_img_music.addEventListener(hmUI.event.CLICK_DOWN, function (info) {
              hmApp.startApp({ appid: 1, url: 'PhoneMusicCtrlScreen', native: true })
            });

           //World Time shortcut
            normal_img_worldtime = hmUI.createWidget(hmUI.widget.IMG, {
              x: 117,
              y: 4,
              w: 100,
              h: 74,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_img_worldtime.addEventListener(hmUI.event.CLICK_DOWN, function (info) {
              hmApp.startApp({ appid: 1, url: 'WorldClockScreen', native: true })
            });

           //Calendar shortcut
            normal_img_calendar = hmUI.createWidget(hmUI.widget.IMG, {
              x: 21,
              y: 16,
              w: 80,
              h: 134,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_img_calendar.addEventListener(hmUI.event.CLICK_DOWN, function (info) {
              hmApp.startApp({ appid: 1, url: 'ScheduleCalScreen', native: true })
            });

           //Find Phone shortcut
            normal_img_findphone = hmUI.createWidget(hmUI.widget.IMG, {
              x: 317,
              y: 116,
              w: 74,
              h: 100,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_img_findphone.addEventListener(hmUI.event.CLICK_DOWN, function (info) {
              hmApp.startApp({ appid: 1, url: 'FindPhoneScreen', native: true })
            });

           //Battery Manager shortcut
            normal_img_batterymanager = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 165,
              w: 70,
              h: 85,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_img_batterymanager.addEventListener(hmUI.event.CLICK_DOWN, function (info) {
              hmApp.startApp({ appid: 1, url: 'Settings_batteryManagerScreen', native: true })
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 234,
              y: 4,
              w: 100,
              h: 74,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 254,
              y: 321,
              w: 100,
              h: 100,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 53,
              y: 373,
              w: 100,
              h: 78,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 53,
              y: 261,
              w: 100,
              h: 100,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function text_update() {

              console.log('update text circle hour_TIME');
              let valueHour = timeNaw.hour;
              if (!timeNaw.is24Hour) {
                valueHour -= 12;
                if (valueHour < 1) valueHour += 12;
              };
              let normal_hour_circle_string = parseInt(valueHour).toString();
              normal_hour_circle_string = normal_hour_circle_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_hour_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = -17;
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_circle_string.length > 0 && normal_hour_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_hour_TextCircle_img_angle = 0;
                  let normal_hour_TextCircle_dot_img_angle = 0;
                  let normal_hour_TextCircle_unit_angle = 0;
                  normal_hour_TextCircle_img_angle = toDegree(Math.atan2(normal_hour_TextCircle_img_width/2, 112));
                  normal_hour_TextCircle_unit_angle = toDegree(Math.atan2(normal_hour_TextCircle_unit_width/2, 112));
                  // alignment = CENTER_H
                  let normal_hour_TextCircle_angleOffset = normal_hour_TextCircle_img_angle * (normal_hour_circle_string.length - 1);
                  normal_hour_TextCircle_angleOffset = normal_hour_TextCircle_angleOffset + 4 * (normal_hour_circle_string.length - 1) / 2;
                  char_Angle -= normal_hour_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_hour_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_hour_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.POS_X, 224 - normal_hour_TextCircle_img_width / 2);
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.SRC, normal_hour_TextCircle_ASCIIARRAY[charCode]);
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_hour_TextCircle_img_angle + 4;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle += normal_hour_TextCircle_unit_angle;
                  normal_hour_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_hour_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_hour_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_hour_TextCircle[0].setProperty(hmUI.prop.POS_X, 224 - normal_hour_TextCircle_error_img_width / 2);
                  normal_hour_TextCircle[0].setProperty(hmUI.prop.SRC, '0052.png');
                  normal_hour_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle minute_TIME');
              let valueMinute = timeNaw.minute;
              let normal_minute_circle_string = parseInt(valueMinute).toString();
              normal_minute_circle_string = normal_minute_circle_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_minute_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 17;
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && normal_minute_circle_string.length > 0 && normal_minute_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_minute_TextCircle_img_angle = 0;
                  let normal_minute_TextCircle_dot_img_angle = 0;
                  normal_minute_TextCircle_img_angle = toDegree(Math.atan2(normal_minute_TextCircle_img_width/2, 112));
                  // alignment = CENTER_H
                  let normal_minute_TextCircle_angleOffset = normal_minute_TextCircle_img_angle * (normal_minute_circle_string.length - 1);
                  normal_minute_TextCircle_angleOffset = normal_minute_TextCircle_angleOffset + 4 * (normal_minute_circle_string.length - 1) / 2;
                  char_Angle -= normal_minute_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_minute_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_minute_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.POS_X, 224 - normal_minute_TextCircle_img_width / 2);
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.SRC, normal_minute_TextCircle_ASCIIARRAY[charCode]);
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_minute_TextCircle_img_angle + 4;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_minute_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_minute_TextCircle[0].setProperty(hmUI.prop.POS_X, 224 - normal_minute_TextCircle_error_img_width / 2);
                  normal_minute_TextCircle[0].setProperty(hmUI.prop.SRC, '0052.png');
                  normal_minute_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle hour_TIME');
              let idle_hour_circle_string = parseInt(valueHour).toString();
              idle_hour_circle_string = idle_hour_circle_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_hour_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_hour_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = -17;
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && idle_hour_circle_string.length > 0 && idle_hour_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_hour_TextCircle_img_angle = 0;
                  let idle_hour_TextCircle_dot_img_angle = 0;
                  let idle_hour_TextCircle_unit_angle = 0;
                  idle_hour_TextCircle_img_angle = toDegree(Math.atan2(idle_hour_TextCircle_img_width/2, 112));
                  idle_hour_TextCircle_unit_angle = toDegree(Math.atan2(idle_hour_TextCircle_unit_width/2, 112));
                  // alignment = CENTER_H
                  let idle_hour_TextCircle_angleOffset = idle_hour_TextCircle_img_angle * (idle_hour_circle_string.length - 1);
                  idle_hour_TextCircle_angleOffset = idle_hour_TextCircle_angleOffset + 4 * (idle_hour_circle_string.length - 1) / 2;
                  char_Angle -= idle_hour_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_hour_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_hour_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_hour_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_hour_TextCircle[index].setProperty(hmUI.prop.POS_X, 224 - idle_hour_TextCircle_img_width / 2);
                      idle_hour_TextCircle[index].setProperty(hmUI.prop.SRC, idle_hour_TextCircle_ASCIIARRAY[charCode]);
                      idle_hour_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_hour_TextCircle_img_angle + 4;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle += idle_hour_TextCircle_unit_angle;
                  idle_hour_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_hour_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  idle_hour_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_hour_TextCircle[0].setProperty(hmUI.prop.POS_X, 224 - idle_hour_TextCircle_error_img_width / 2);
                  idle_hour_TextCircle[0].setProperty(hmUI.prop.SRC, '0052.png');
                  idle_hour_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle minute_TIME');
              let idle_minute_circle_string = parseInt(valueMinute).toString();
              idle_minute_circle_string = idle_minute_circle_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_minute_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 17;
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && idle_minute_circle_string.length > 0 && idle_minute_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_minute_TextCircle_img_angle = 0;
                  let idle_minute_TextCircle_dot_img_angle = 0;
                  idle_minute_TextCircle_img_angle = toDegree(Math.atan2(idle_minute_TextCircle_img_width/2, 112));
                  // alignment = CENTER_H
                  let idle_minute_TextCircle_angleOffset = idle_minute_TextCircle_img_angle * (idle_minute_circle_string.length - 1);
                  idle_minute_TextCircle_angleOffset = idle_minute_TextCircle_angleOffset + 4 * (idle_minute_circle_string.length - 1) / 2;
                  char_Angle -= idle_minute_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_minute_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_minute_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_minute_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_minute_TextCircle[index].setProperty(hmUI.prop.POS_X, 224 - idle_minute_TextCircle_img_width / 2);
                      idle_minute_TextCircle[index].setProperty(hmUI.prop.SRC, idle_minute_TextCircle_ASCIIARRAY[charCode]);
                      idle_minute_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_minute_TextCircle_img_angle + 4;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  idle_minute_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_minute_TextCircle[0].setProperty(hmUI.prop.POS_X, 224 - idle_minute_TextCircle_error_img_width / 2);
                  idle_minute_TextCircle[0].setProperty(hmUI.prop.SRC, '0052.png');
                  idle_minute_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

            };

            function scale_call() {

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = 1 - progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 106,
                      center_y: 344,
                      start_angle: 360,
                      end_angle: 0,
                      radius: 95,
                      line_width: 11,
                      corner_flag: 3,
                      color: 0xFF585858,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

                console.log('update scales STEP');
                let progress_cs_idle_step = 1 - progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_step * 100);
                  if (idle_step_circle_scale) {
                    idle_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 106,
                      center_y: 344,
                      start_angle: 360,
                      end_angle: 0,
                      radius: 95,
                      line_width: 11,
                      corner_flag: 3,
                      color: 0xFF585858,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

              console.log('Weather city name');
              idle_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}