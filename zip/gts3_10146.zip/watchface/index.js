﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let editBg = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 390,
              // h: 450,
              // AOD_show: True,
              bg_config: [
                { id: 1, preview: 'BG_1.png', path: 'BG_1.png' },
                { id: 2, preview: 'BG_2.png', path: 'BG_2.png' },
                { id: 3, preview: 'BG_3.png', path: 'BG_3.png' },
                { id: 4, preview: 'BG_4.png', path: 'BG_4.png' },
                { id: 5, preview: 'BG_5.png', path: 'BG_5.png' },
                { id: 6, preview: 'BG_6.png', path: 'BG_6.png' },
                { id: 7, preview: 'BG_7.png', path: 'BG_7.png' },
                { id: 8, preview: 'BG_8.png', path: 'BG_8.png' },
                { id: 9, preview: 'BG_10.png', path: 'BG_10.png' },
              ],
              count: 9,
              default_id: 1,
              fg: 'fg.png',
              tips_bg: 'input_short.png',
              tips_x: 142,
              tips_y: 200,
            });




            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  