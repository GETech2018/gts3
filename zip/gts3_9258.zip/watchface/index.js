﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_system_dnd_img = ''
        let normal_system_clock_img = ''
        let normal_step_icon_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_battery_icon_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month = ''
        let idle_date_month_separator_img = ''
        let idle_date_img_date_week_img = ''
        let idle_system_dnd_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: '02.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 288,
              day_startY: 163,
              day_sc_array: ["34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png"],
              day_tc_array: ["34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png"],
              day_en_array: ["34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png"],
              day_zero: 1,
              day_space: -1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 219,
              month_startY: 163,
              month_sc_array: ["34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png"],
              month_tc_array: ["34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png"],
              month_en_array: ["34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png"],
              month_zero: 1,
              month_space: -1,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 264,
              y: 163,
              src: '56.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 208,
              y: 119,
              week_en: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png"],
              week_tc: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png"],
              week_sc: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 87,
              y: 257,
              src: '23.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 120,
              y: 250,
              src: '24.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 208,
              y: 373,
              src: 'stp.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 211,
              y: 375,
              image_array: ["0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 94,
              y: 373,
              src: 'pw.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 99,
              y: 375,
              image_array: ["45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 165,
              am_y: 300,
              am_sc_path: '25.png',
              am_en_path: '25.png',
              pm_x: 165,
              pm_y: 300,
              pm_sc_path: '26.png',
              pm_en_path: '26.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 76,
              hour_startY: 83,
              hour_array: ["03.png","04.png","05.png","06.png","07.png","08.png","09.png","10.png","11.png","12.png"],
              hour_zero: 1,
              hour_space: -8,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 217,
              minute_startY: 225,
              minute_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              minute_zero: 1,
              minute_space: -8,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: '02.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 288,
              day_startY: 163,
              day_sc_array: ["34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png"],
              day_tc_array: ["34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png"],
              day_en_array: ["34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png"],
              day_zero: 1,
              day_space: -1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 219,
              month_startY: 163,
              month_sc_array: ["34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png"],
              month_tc_array: ["34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png"],
              month_en_array: ["34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png"],
              month_zero: 1,
              month_space: -1,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 264,
              y: 163,
              src: '56.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 208,
              y: 119,
              week_en: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png"],
              week_tc: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png"],
              week_sc: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 87,
              y: 257,
              src: '23.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 120,
              y: 250,
              src: '24.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 165,
              am_y: 300,
              am_sc_path: '25.png',
              am_en_path: '25.png',
              pm_x: 165,
              pm_y: 300,
              pm_sc_path: '26.png',
              pm_en_path: '26.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 76,
              hour_startY: 83,
              hour_array: ["03.png","04.png","05.png","06.png","07.png","08.png","09.png","10.png","11.png","12.png"],
              hour_zero: 1,
              hour_space: -8,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 217,
              minute_startY: 225,
              minute_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              minute_zero: 1,
              minute_space: -8,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  