﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

let cc = 0;
		
		let COVERstyle = 0;
        function click_COVER() {
			COVERstyle=COVERstyle+1;
            if(COVERstyle>9)  {COVERstyle=0;}
			hmUI.showToast({text: "COVER "+ COVERstyle }); 
			normal_image_img.setProperty(hmUI.prop.SRC, "cov" + COVERstyle + ".png");
			if(COVERstyle==0)  {
            	//hmUI.showToast({text: 'Animation: ON'});
            	normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
            	normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE,    true);
            	//normal_background_bg_img.setProperty(hmUI.prop.SRC,"bg0.png");
             }else{
            	//hmUI.showToast({text: 'Animation: OFF'});
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE,    false);
                //normal_background_bg_img.setProperty(hmUI.prop.SRC,"bg0.png"); 
            }	
        }

		let BACKstyle = 0;
        function click_BACKGROUND() {
			BACKstyle=BACKstyle+1;
            if(BACKstyle>24)  {BACKstyle=0;}
			hmUI.showToast({text: "BACKGROUND "+ BACKstyle }); normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg" + BACKstyle + ".png");
        }
/*		
		let MODEnumber = 1;
        function click_MODE() {
			MODEnumber=MODEnumber+1;
            if(MODEnumber>3)  {MODEnumber=0;}
			
			hmUI.showToast({text: "MODE " + MODEnumber });
			
			normal_hour_TextCircle[0].setProperty(hmUI.prop.VISIBLE, MODEnumber==1);
            normal_hour_TextCircle[1].setProperty(hmUI.prop.VISIBLE, MODEnumber==1);
            normal_hour_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, MODEnumber==1);
            normal_minute_TextCircle[0].setProperty(hmUI.prop.VISIBLE, MODEnumber==1);
            normal_minute_TextCircle[1].setProperty(hmUI.prop.VISIBLE, MODEnumber==1);
            normal_minute_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, MODEnumber==1);
            normal_second_TextCircle[0].setProperty(hmUI.prop.VISIBLE, MODEnumber==1);
            normal_second_TextCircle[1].setProperty(hmUI.prop.VISIBLE, MODEnumber==1);
			
			normal_step_TextCircle[0].setProperty(hmUI.prop.VISIBLE, MODEnumber==2);
            normal_step_TextCircle[1].setProperty(hmUI.prop.VISIBLE, MODEnumber==2);
            normal_step_TextCircle[2].setProperty(hmUI.prop.VISIBLE, MODEnumber==2);
            normal_step_TextCircle[3].setProperty(hmUI.prop.VISIBLE, MODEnumber==2);
            normal_step_TextCircle[4].setProperty(hmUI.prop.VISIBLE, MODEnumber==2);
            normal_step_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, MODEnumber==2);
            
			normal_distance_TextCircle[0].setProperty(hmUI.prop.VISIBLE, MODEnumber==2);
            normal_distance_TextCircle[1].setProperty(hmUI.prop.VISIBLE, MODEnumber==2);
            normal_distance_TextCircle[2].setProperty(hmUI.prop.VISIBLE, MODEnumber==2);
            normal_distance_TextCircle[3].setProperty(hmUI.prop.VISIBLE, MODEnumber==2);
            normal_distance_TextCircle[4].setProperty(hmUI.prop.VISIBLE, MODEnumber==2);
            normal_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, MODEnumber==2);
            
            normal_heart_rate_TextCircle[0].setProperty(hmUI.prop.VISIBLE, MODEnumber==3);
            normal_heart_rate_TextCircle[1].setProperty(hmUI.prop.VISIBLE, MODEnumber==3);
            normal_heart_rate_TextCircle[2].setProperty(hmUI.prop.VISIBLE, MODEnumber==3);
            normal_heart_rate_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, MODEnumber==3);
            normal_spo2_TextCircle[0].setProperty(hmUI.prop.VISIBLE, MODEnumber==3);
            normal_spo2_TextCircle[1].setProperty(hmUI.prop.VISIBLE, MODEnumber==3);
            normal_spo2_TextCircle[2].setProperty(hmUI.prop.VISIBLE, MODEnumber==3);
            normal_spo2_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, MODEnumber==3);
            normal_calorie_TextCircle[0].setProperty(hmUI.prop.VISIBLE, MODEnumber==3);
            normal_calorie_TextCircle[1].setProperty(hmUI.prop.VISIBLE, MODEnumber==3);
            normal_calorie_TextCircle[2].setProperty(hmUI.prop.VISIBLE, MODEnumber==3);
            normal_calorie_TextCircle[3].setProperty(hmUI.prop.VISIBLE, MODEnumber==3);
			
        }
*/
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_frame_animation_1 = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_image_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'bg0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'cov0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 0,
              y: 0,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "anim",
              anim_fps: 15,
              anim_size: 21,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 214,
              day_startY: 123,
              day_sc_array: ["numw0.png","numw1.png","numw2.png","numw3.png","numw4.png","numw5.png","numw6.png","numw7.png","numw8.png","numw9.png"],
              day_tc_array: ["numw0.png","numw1.png","numw2.png","numw3.png","numw4.png","numw5.png","numw6.png","numw7.png","numw8.png","numw9.png"],
              day_en_array: ["numw0.png","numw1.png","numw2.png","numw3.png","numw4.png","numw5.png","numw6.png","numw7.png","numw8.png","numw9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 124,
              y: 122,
              week_en: ["dayw1.png","dayw2.png","dayw3.png","dayw4.png","dayw5.png","dayw6.png","dayw7.png"],
              week_tc: ["dayw1.png","dayw2.png","dayw3.png","dayw4.png","dayw5.png","dayw6.png","dayw7.png"],
              week_sc: ["dayw1.png","dayw2.png","dayw3.png","dayw4.png","dayw5.png","dayw6.png","dayw7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'pointerwhour.png',
              hour_centerX: 195,
              hour_centerY: 225,
              hour_posX: 22,
              hour_posY: 99,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'pointerwminutes.png',
              minute_centerX: 195,
              minute_centerY: 225,
              minute_posX: 25,
              minute_posY: 170,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'pointerwseconds.png',
              second_centerX: 195,
              second_centerY: 225,
              second_posX: 13,
              second_posY: 180,
              second_cover_path: 'pointercenter.png',
              second_cover_x: 186,
              second_cover_y: 217,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'bg0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'cov0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 214,
              day_startY: 123,
              day_sc_array: ["numw0.png","numw1.png","numw2.png","numw3.png","numw4.png","numw5.png","numw6.png","numw7.png","numw8.png","numw9.png"],
              day_tc_array: ["numw0.png","numw1.png","numw2.png","numw3.png","numw4.png","numw5.png","numw6.png","numw7.png","numw8.png","numw9.png"],
              day_en_array: ["numw0.png","numw1.png","numw2.png","numw3.png","numw4.png","numw5.png","numw6.png","numw7.png","numw8.png","numw9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 124,
              y: 122,
              week_en: ["dayw1.png","dayw2.png","dayw3.png","dayw4.png","dayw5.png","dayw6.png","dayw7.png"],
              week_tc: ["dayw1.png","dayw2.png","dayw3.png","dayw4.png","dayw5.png","dayw6.png","dayw7.png"],
              week_sc: ["dayw1.png","dayw2.png","dayw3.png","dayw4.png","dayw5.png","dayw6.png","dayw7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'pointerwhour.png',
              hour_centerX: 195,
              hour_centerY: 225,
              hour_posX: 22,
              hour_posY: 99,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'pointerwminutes.png',
              minute_centerX: 195,
              minute_centerY: 225,
              minute_posX: 25,
              minute_posY: 170,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'pointerwseconds.png',
              second_centerX: 195,
              second_centerY: 225,
              second_posX: 13,
              second_posY: 180,
              second_cover_path: 'pointercenter.png',
              second_cover_x: 186,
              second_cover_y: 217,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 135,
              y: 0,
              w: 120,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'button.png',
              normal_src: 'buttblank.png',
              click_func: (button_widget) => {
                click_COVER();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 135,
              y: 380,
              w: 120,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'button.png',
              normal_src: 'buttblank.png',
              click_func: (button_widget) => {
                click_BACKGROUND();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 135,
              y: 170,
              w: 120,
              h: 120,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'button.png',
              normal_src: 'buttblank.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

if (cc ==0 ){
	click_MODE();
	cc = 1;
}
/*
  if (screenType != hmSetting.screen_type.AOD && MODEnumber==2) {
==1 TIME 
==2 STEPS, DISTANCE
==3 HEART, SPO, call


*/
            // end user_script_end.js

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}