/*
** Facemaker bundle tool v0.0.2
* *huamiOS watchface js version v2.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_background_bg_img0 = '';
		let normal_battery_current_text_img2 = '';
		let normal_battery_image_progress_img_level3 = '';
		let normal_date_current_date_year5 = '';
		let normal_date_current_date_month6 = '';
		let normal_date_current_date_monthday7 = '';
		let normal_date_img_date_week_img8 = '';
		let normal_step_current_text_img10 = '';
		let normal_heart_current_text_img12 = '';
		let normal_background_bg_img14 = '';
		let normal_digital_clock_img_hour15 = '';
		let normal_digital_clock_img_minute16 = '';
		let normal_anim_img18 = '';
		let normal_temperature_current_text_img20 = '';
		let normal_weather_image_progress_img_level21 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				let screenType = hmSetting.getScreenType();

				normal_background_bg_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 390,
					h: 450,
					src: '0002.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_current_text_img2 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 275,
					y: 222,
					font_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
					padding: false,
					h_space: 0,
					unit_sc: '0013.png',
					unit_tc: '0013.png',
					unit_en: '0013.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_image_progress_img_level3 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 319,
					y: 192,
					image_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
					image_length: 10,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_current_date_year5 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					year_startX: 225,
					year_startY: 42,
					year_sc_array: ["0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png"],
					year_tc_array: ["0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png"],
					year_en_array: ["0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png"],
					year_zero: false,
					year_space: 0,
					year_align: hmUI.align.CENTER_H,
					year_is_character: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_current_date_month6 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 139,
					month_startY: 44,
					month_sc_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
					month_tc_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
					month_en_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
					month_zero: true,
					month_space: 0,
					month_align: hmUI.align.CENTER_H,
					month_is_character: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_current_date_monthday7 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 58,
					day_startY: 44,
					day_sc_array: ["0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png"],
					day_tc_array: ["0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png"],
					day_en_array: ["0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png"],
					day_zero: true,
					day_space: 0,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_img_date_week_img8 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 122,
					y: 6,
					week_en: ["0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png"],
					week_tc: ["0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png"],
					week_sc: ["0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png"],
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_step_current_text_img10 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 38,
					y: 412,
					font_array: ["0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png"],
					padding: false,
					h_space: -1,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_current_text_img12 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 268,
					y: 412,
					font_array: ["0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png"],
					padding: false,
					h_space: -1,
					invalid_image: '0081.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img14 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 186,
					y: 97,
					w: 17,
					h: 76,
					src: '0082.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_digital_clock_img_hour15 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 11,
					hour_startY: 93,
					hour_array: ["0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.CENTER_H,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_digital_clock_img_minute16 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 209,
					minute_startY: 93,
					minute_array: ["0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.CENTER_H,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				if (screenType != hmSetting.screen_type.AOD) {
					normal_anim_img18 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
						x: 74,
						y: 207,
						anim_path: '',
						anim_prefix: '1669474890674',
						anim_ext: 'png',
						anim_fps: 20,
						anim_size: 6,
						anim_repeat: true,
						repeat_count: 0,
						anim_status: hmUI.anim_status.START,
						display_on_restart: false,
					});
				};

				normal_temperature_current_text_img20 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 281,
					y: 319,
					font_array: ["0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png","0116.png","0117.png","0118.png"],
					padding: false,
					h_space: 0,
					unit_sc: ["0120.png"],
					unit_tc: ["0120.png"],
					unit_en: ["0120.png"],
					negative_image: ["0119.png"],
					invalid_image: ["0121.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_image_progress_img_level21 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 314,
					y: 267,
					image_array: ["0122.png","0123.png","0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}