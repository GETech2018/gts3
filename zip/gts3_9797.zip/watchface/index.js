﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_pai_circle_scale = ''
        let normal_calorie_circle_scale = ''
        let normal_heart_rate_circle_scale = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_text_text_img = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_date_img_date_week_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_hour = ''

        //dynamic modify end

        let secondPic = null;
        let now = null;
        let timer_sec_anim = null;
        let lastTime = 0;
        let animDuration = 5000;
        var secAnim = {
            "anim_rate": 'linear',
            "anim_duration": animDuration,
            "anim_from": 0,
            "anim_to": 360,
            "repeat_count": 1,
            "anim_fps": 25,
            "anim_key": "angle",
            "anim_status": 1,
        }
        /**
         * 在合适的层级调用此方法即可
         */
        function setSec() {
            if (now == null) {
                now = hmSensor.createSensor(hmSensor.id.TIME);
            }
            var screenType = hmSetting.getScreenType();
            if (screenType == hmSetting.screen_type.AOD) {
                stopSecAnim();
            } else {
                secondPic = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 390,
                    h: 450,
                    pos_x: 390 / 2 - 20,
                    pos_y: 450 / 2 - 211,
                    center_x: 194,
                    center_y: 226,
                    src:  "4.png",
                    angle: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                })
            }
            var vDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                resume_call: (function () {//划入表盘
                    console.log('ui resume');
                    if (timer_sec_anim != null && timer_sec_anim != 0) return;
                    let duration = now.utc - lastTime;
                    if (duration < animDuration) {
                        duration = animDuration - duration;
                    } else {
                        duration = 0;
                    }
                    timer_sec_anim = timer.createTimer(duration, animDuration, (function (option) {
                        lastTime = now.utc;
                        startSecAnim();
                    }));
                }),
                pause_call: (function () {
                    console.log('ui pause');
                    stopSecAnim();
                }),
            });
        }

        function startSecAnim() {
            let sec = now.second * 6;
            secAnim["anim_from"] = sec;
            secAnim["anim_to"] = sec + animDuration * 6 / 1000;

            secondPic.setProperty(hmUI.prop.ANIM, secAnim);
        }

        /**
         * onDestroy()中要调用一下这个方法
         */
        function stopSecAnim() {
            timer.stopTimer(timer_sec_anim);
            timer_sec_anim = 0;
        }

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start

                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: '01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 303,
              y: 273,
              src: 'blue.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 265,
              y: 270,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '6.png',
              center_x: 195,
              center_y: 121,
              x: 28,
              y: 53,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 268,
              y: 300,
              week_en: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              week_tc: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              week_sc: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 278,
              y: 129,
              font_array: ["midFont_01.png","midFont_02.png","midFont_03.png","midFont_04.png","midFont_05.png","midFont_06.png","midFont_07.png","midFont_08.png","midFont_09.png","midFont_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Weather_Font_13.png',
              unit_tc: 'Weather_Font_13.png',
              unit_en: 'Weather_Font_13.png',
              negative_image: 'Weather_Font_12.png',
              invalid_image: 'Weather_Font_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 295,
              y: 89,
              image_array: ["0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png","0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png","0163.png","0164.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '6.png',
              center_x: 86,
              center_y: 225,
              x: 28,
              y: 53,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 61,
              y: 324,
              font_array: ["smallFont_01.png","smallFont_02.png","smallFont_03.png","smallFont_04.png","smallFont_05.png","smallFont_06.png","smallFont_07.png","smallFont_08.png","smallFont_09.png","smallFont_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'smallFont_11.png',
              unit_tc: 'smallFont_11.png',
              unit_en: 'smallFont_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 66,
              y: 116,
              font_array: ["smallFont_01.png","smallFont_02.png","smallFont_03.png","smallFont_04.png","smallFont_05.png","smallFont_06.png","smallFont_07.png","smallFont_08.png","smallFont_09.png","smallFont_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 171,
              day_startY: 338,
              day_sc_array: ["act_font_01.png","act_font_02.png","act_font_03.png","act_font_04.png","act_font_05.png","act_font_06.png","act_font_07.png","act_font_08.png","act_font_09.png","act_font_10.png"],
              day_tc_array: ["act_font_01.png","act_font_02.png","act_font_03.png","act_font_04.png","act_font_05.png","act_font_06.png","act_font_07.png","act_font_08.png","act_font_09.png","act_font_10.png"],
              day_en_array: ["act_font_01.png","act_font_02.png","act_font_03.png","act_font_04.png","act_font_05.png","act_font_06.png","act_font_07.png","act_font_08.png","act_font_09.png","act_font_10.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 163,
              month_startY: 302,
              month_sc_array: ["Month_icons_01.png","Month_icons_02.png","Month_icons_03.png","Month_icons_04.png","Month_icons_05.png","Month_icons_06.png","Month_icons_07.png","Month_icons_08.png","Month_icons_09.png","Month_icons_10.png","Month_icons_11.png","Month_icons_12.png"],
              month_tc_array: ["Month_icons_01.png","Month_icons_02.png","Month_icons_03.png","Month_icons_04.png","Month_icons_05.png","Month_icons_06.png","Month_icons_07.png","Month_icons_08.png","Month_icons_09.png","Month_icons_10.png","Month_icons_11.png","Month_icons_12.png"],
              month_en_array: ["Month_icons_01.png","Month_icons_02.png","Month_icons_03.png","Month_icons_04.png","Month_icons_05.png","Month_icons_06.png","Month_icons_07.png","Month_icons_08.png","Month_icons_09.png","Month_icons_10.png","Month_icons_11.png","Month_icons_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 277,
              hour_startY: 183,
              hour_array: ["Time_b_font_01.png","Time_b_font_02.png","Time_b_font_03.png","Time_b_font_04.png","Time_b_font_05.png","Time_b_font_06.png","Time_b_font_07.png","Time_b_font_08.png","Time_b_font_09.png","Time_b_font_10.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_align: hmUI.align.LEFT,

              minute_startX: 277,
              minute_startY: 228,
              minute_array: ["Time_b_font_01.png","Time_b_font_02.png","Time_b_font_03.png","Time_b_font_04.png","Time_b_font_05.png","Time_b_font_06.png","Time_b_font_07.png","Time_b_font_08.png","Time_b_font_09.png","Time_b_font_10.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '2.png',
              hour_centerX: 194,
              hour_centerY: 226,
              hour_posX: 21,
              hour_posY: 213,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '3.png',
              minute_centerX: 194,
              minute_centerY: 226,
              minute_posX: 21,
              minute_posY: 212,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {

            });

            setSec();


            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 257,
              y: 77,
              w: 100,
              h: 78,
              src: '0057.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 63,
              y: 97,
              w: 50,
              h: 50,
              src: '0057.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 145,
              y: 68,
              w: 100,
              h: 100,
              src: '0057.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 277,
              hour_startY: 183,
              hour_array: ["Time_HM_font_01.png","Time_HM_font_02.png","Time_HM_font_03.png","Time_HM_font_04.png","Time_HM_font_05.png","Time_HM_font_06.png","Time_HM_font_07.png","Time_HM_font_08.png","Time_HM_font_09.png","Time_HM_font_10.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_align: hmUI.align.LEFT,

              minute_startX: 277,
              minute_startY: 228,
              minute_array: ["Time_HM_font_01.png","Time_HM_font_02.png","Time_HM_font_03.png","Time_HM_font_04.png","Time_HM_font_05.png","Time_HM_font_06.png","Time_HM_font_07.png","Time_HM_font_08.png","Time_HM_font_09.png","Time_HM_font_10.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '2.png',
              hour_centerX: 194,
              hour_centerY: 226,
              hour_posX: 21,
              hour_posY: 213,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '3.png',
              minute_centerX: 194,
              minute_centerY: 226,
              minute_posX: 21,
              minute_posY: 212,
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  