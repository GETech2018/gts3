﻿try {
    (() => {
    
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface6');

        
        let img_hour = hmUI.createWidget(hmUI.widget.IMG);
        let img_minute = hmUI.createWidget(hmUI.widget.IMG);
        //let img_hour_aod = hmUI.createWidget(hmUI.widget.IMG);
        //let img_minute_aod = hmUI.createWidget(hmUI.widget.IMG);
        let image_bt_aod = '';
        let image_bt = '';
        let btn_aod = '';
        let btn_battery = '';
        let normal_digital_clock_img_time = '';
        let idle_digital_clock_img_time = '';
        let btn_change_hour = '';
        let btn_change_minute = '';
        let btn_change_hour_next = '';
        let btn_change_minute_next = '';
        let normal_dialog_window = '';

        let is_window_opened = false;
        let timer_CloseDialog = null;

        let curr_hour = 0;
        let curr_minute = 0;
        
        let curAODmode = 0; // 0 - AOD Minimal  // 1 - AOD Disabled
        let AODmodes = ["Minimal", "Disabled"];
        let AODmodeCaption = '';
        
        function change_hour_prev() {
          curr_hour = curr_hour - 1;
          if (curr_hour < 0) {
            curr_hour = 30;
          }
          img_hour.setProperty(hmUI.prop.SRC, "font_" + curr_hour + ".png");
        }
        
        function change_minute_prev() {
          curr_minute = curr_minute - 1;
          if (curr_minute < 0) {
            curr_minute = 30;
          }
          img_minute.setProperty(hmUI.prop.SRC, "font_" + curr_minute + ".png");
        }
        
        function change_hour_next() {
          curr_hour = curr_hour + 1;
          if (curr_hour > 30) {
            curr_hour = 0;
          }
          img_hour.setProperty(hmUI.prop.SRC, "font_" + curr_hour + ".png");
        }
        
        function change_minute_next() {
          curr_minute = curr_minute + 1;
          if (curr_minute > 30) {
            curr_minute = 0;
          }
          img_minute.setProperty(hmUI.prop.SRC, "font_" + curr_minute + ".png");
        }

        function makeAOD() {
            let mode = hmFS.SysProGetInt('parkur_aod');
            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 22,
              hour_startY: 21,
              hour_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              hour_zero: 1,
              hour_space: 15,
              hour_align: hmUI.align.LEFT,

              minute_startX: 23,
              minute_startY: 229,
              minute_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              minute_zero: 1,
              minute_space: 14,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            let image_bt_aod = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 315,
                    y: 20,
                    src: 'disconnect.png',
                    type: hmUI.system_status.DISCONNECT,
                    show_level: hmUI.show_level.ONLY_AOD
                });
            if (mode == 0) { // ENABLE
                idle_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, true);
                img_hour.setProperty(hmUI.prop.VISIBLE, true);
                img_minute.setProperty(hmUI.prop.VISIBLE, true);
                //image_battery_icon_aod.setProperty(hmUI.prop.VISIBLE, true);   
                //image_battery_aod.setProperty(hmUI.prop.VISIBLE, true);   
	    }
	    if (mode == 1) { // DISABLE
                idle_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
                img_hour.setProperty(hmUI.prop.VISIBLE, false);
                img_minute.setProperty(hmUI.prop.VISIBLE, false);
                //image_battery_icon_aod.setProperty(hmUI.prop.VISIBLE, false);                
                //image_battery_aod.setProperty(hmUI.prop.VISIBLE, false);                
	    }
        }  
        
        function toggleAODmode() {
            curAODmode = (curAODmode + 1) % AODmodes.length;
            hmFS.SysProSetInt('parkur_aod', curAODmode);

            switch (curAODmode) {
                case 0:
                    AODmodeCaption = "Enabled";
                    break;
                case 1:
                    AODmodeCaption = "Disabled";
                    break;
                default:
                    AODmodeCaption = "";
                    break;
            }

            hmUI.showToast({ text: 'AOD: ' + AODmodeCaption });
        }  
        
function ShowBatteryInfo() {
    if (is_window_opened) return;
    is_window_opened = true;
    
    // AREA DEFINITION TO CLOSE WHEN PRESS OUTSIDE OF RECTANGLE
    normal_dialog_window = hmUI.createWidget(hmUI.widget.GROUP, {
        x: 0,
        y: 0,
        w: 466,
        h: 466,
    });

    normal_dialog_window.createWidget(hmUI.widget.BUTTON, {
        x: 0,
        y: 0,
        w: 466,
        h: 466,
        text: '',
        normal_src: 'click_e.png',
        press_src: 'click_e.png',
        click_func: (button_widget) => {
            CloseDialog();
        },
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    // DIALOG DEFINITION RECTANGLE - BEGIN
    let fr = normal_dialog_window.createWidget(hmUI.widget.FILL_RECT, {
        x: 45,
        y: 90,
        w: 310,
        h: 280,
        color: 0xa9ada8,//bg_color[bg_color_cur],
        radius: 20,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });
    let sr = normal_dialog_window.createWidget(hmUI.widget.STROKE_RECT, {
        x: 45,
        y: 90,
        w: 310,
        h: 280,
        color: 0x555555,
        radius: 20,
        line_width: 4,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });
    // DIALOG DEFINITION RECTANGLE - END

    // CLOSE BUTTON
    normal_dialog_window.createWidget(hmUI.widget.BUTTON, {
        x: 293,
        y: 95,
        w: 50,
        h: 32,
        text: 'X',
        radius: 16,
        color: 0xff0000,
        normal_color: 0xa9ada8, //bg_color[bg_color_cur],
        press_color: 0x000000,
        click_func: (button_widget) => {
            CloseDialog();
        },
        text_size: 33,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    // PERCENTAGE SIMBOL
    normal_dialog_window.createWidget(hmUI.widget.IMG, {
        x: 273,
        y: 243, //223,
        src: 'battery_percent.png',
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    let title_dialog = normal_dialog_window.createWidget(hmUI.widget.TEXT, {
        x: 55,
        y: 90,
        w: 248,
        h: 45,
        text_size: 28,
        char_space: 0,
        line_space: 0,
        color: 0xFF000000,
        text: 'Battery Level',
        align_h: hmUI.align.CENTER_H,
        align_v: hmUI.align.TOP,
        text_style: hmUI.text_style.NONE,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    let battery_text = normal_dialog_window.createWidget(hmUI.widget.TEXT_IMG, {
        x: 70,
        y: 190,
        font_array: ["B_Numb_00.png", "B_Numb_01.png", "B_Numb_02.png", "B_Numb_03.png", "B_Numb_04.png", "B_Numb_05.png", "B_Numb_06.png", "B_Numb_07.png", "B_Numb_08.png", "B_Numb_09.png"],
        padding: false,
        h_space: 0,
        negative_image: 'B_Numb_minus.png',
        align_h: hmUI.align.RIGHT,
        type: hmUI.data_type.BATTERY,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });
}
// END  

    function CloseDialog(){
	if (is_window_opened) {
	    normal_dialog_window.setProperty(hmUI.prop.VISIBLE, false);
            hmUI.deleteWidget(normal_dialog_window);
            is_window_opened = false;
        }
    }


        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
        //dynamic modify start
   
            img_hour.setProperty(hmUI.prop.MORE, {
      		x: 0,
      		y: 16,
      		src: 'font_0.png',
      		//show_level: hmUI.show_level.ONLY_NORMAL,
            });
            img_minute.setProperty(hmUI.prop.MORE, {
      		x: 0,
      		y: 224,
      		src: 'font_0.png',
      		//show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            /*
            img_hour_aod.setProperty(hmUI.prop.MORE, {
      		x: 0,
      		y: 16,
      		src: 'font_0.png',
      		show_level: hmUI.show_level.ONLY_AOD,
            });
            img_minute_aod.setProperty(hmUI.prop.MORE, {
      		x: 0,
      		y: 224,
      		src: 'font_0.png',
      		show_level: hmUI.show_level.ONLY_AOD,
            });
	    */
	    
            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 19,
              hour_startY: 21,
              hour_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              hour_zero: 1,
              hour_space: 12,
              hour_align: hmUI.align.LEFT,

              minute_startX: 19,
              minute_startY: 229,
              minute_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              minute_zero: 1,
              minute_space: 12,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

	    btn_change_hour = hmUI.createWidget(hmUI.widget.BUTTON, {
		  x: 0,
		  y: 80,
                  text: '',
                  w: 55,
                  h: 80,
                  normal_src: 'blank.png',
                  press_src: 'blank.png',
                  click_func: () => {
                    change_hour_prev();
                    vibro(25);
                    //dialog.show(true);
                  },
                  show_level: hmUI.show_level.ONLY_NORMAL,
		});
	    btn_change_hour.setProperty(hmUI.prop.VISIBLE, true);
	    
	    btn_change_minute = hmUI.createWidget(hmUI.widget.BUTTON, {
		  x: 0,
		  y: 290,
                  text: '',
                  w: 55,
                  h: 80,
                  normal_src: 'blank.png',
                  press_src: 'blank.png',
                  click_func: () => {
                    change_minute_prev();
                    vibro(25);
                    //dialog.show(true);
                  },
                  show_level: hmUI.show_level.ONLY_NORMAL,
		});
	    btn_change_minute.setProperty(hmUI.prop.VISIBLE, true);
	    
	    btn_change_hour_next = hmUI.createWidget(hmUI.widget.BUTTON, {
		  x: 332,
		  y: 80,
                  text: '',
                  w: 55,
                  h: 80,
                  normal_src: 'blank.png',
                  press_src: 'blank.png',
                  click_func: () => {
                    change_hour_next();
                    vibro(25);
                    //dialog.show(true);
                  },
                  show_level: hmUI.show_level.ONLY_NORMAL,
		});
	    btn_change_hour_next.setProperty(hmUI.prop.VISIBLE, true);
	    
	    btn_change_minute_next = hmUI.createWidget(hmUI.widget.BUTTON, {
		  x: 332,
		  y: 290,
                  text: '',
                  w: 55,
                  h: 80,
                  normal_src: 'blank.png',
                  press_src: 'blank.png',
                  click_func: () => {
                    change_minute_next();
                    vibro(25);
                    //dialog.show(true);
                  },
                  show_level: hmUI.show_level.ONLY_NORMAL,
		});
	    btn_change_minute_next.setProperty(hmUI.prop.VISIBLE, true);
	    
	    
	    let image_bt = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 346,
                    y: 197,
                    src: 'disconnect.png',
                    type: hmUI.system_status.DISCONNECT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
	    
// vibration when connecting or disconnecting

		function checkConnection() {
		  hmBle.removeListener;
		  hmBle.addListener(function (status) {
		    if(!status) {
		      hmUI.showToast({text: "CONNECTION LOST"});
		      console.log('Disconnected');
		      vibro(9);
		    }
		    if(status) {
		      hmUI.showToast({text: "CONNECTION RESTORED"});
		      console.log('Connected');
		      vibro(9);
		    }
		  });
		}

// end vibration when connecting or disconnecting

// vibrate function

		const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
		let timer_StopVibrate = null;

		function vibro(scene = 25) {
		  let stopDelay = 50;
		  stopVibro();
		  vibrate.stop();
		  vibrate.scene = scene;
		  if(scene < 23 || scene > 25) stopDelay = 1300;
		  vibrate.start();
		  timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
		}

		function stopVibro(){
		  vibrate.stop();
		  if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
		}

// end vibrate function
	    
	    //START AOD Button
		btn_aod = hmUI.createWidget(hmUI.widget.BUTTON, {
		  x: 165,
		  y: 0,
                  text: '',
                  w: 60,
                  h: 60,
                  normal_src: 'blank.png',
                  press_src: 'blank.png',
                  click_func: () => {
                    toggleAODmode();
                    vibro(25);
                    //dialog.show(true);
                  },
                  show_level: hmUI.show_level.ONLY_NORMAL,
		});
		btn_aod.setProperty(hmUI.prop.VISIBLE, true);
	    //END AOD Button
	    
	    //START Battery Button
		btn_battery = hmUI.createWidget(hmUI.widget.BUTTON, {
		  x: 165,
		  y: 390,
                  text: '',
                  w: 60,
                  h: 60,
                  normal_src: 'blank.png',
                  press_src: 'blank.png',
                  click_func: () => {
                    if (is_window_opened) {
                      CloseDialog();
                    }
                    else {
                      ShowBatteryInfo();
                    }
                    vibro(25);
                    //dialog.show(true);
                  },
                  show_level: hmUI.show_level.ONLY_NORMAL,
		});
		btn_battery.setProperty(hmUI.prop.VISIBLE, true);
	    //END battery Button

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                  resume_call: (function () {
                    checkConnection();
                    stopVibro();
                    CloseDialog();
                  }),
                  pause_call: (function () {
                    stopVibro();
                    CloseDialog();
                  }),
                });	

           //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                const currentScreenType = hmSetting.getScreenType();
                switch (currentScreenType) {
                  case hmSetting.screen_type.AOD:
                      makeAOD();
                      break;
                  default:
                      break;
              	}            
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
