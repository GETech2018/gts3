﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_circle_scale = ''
        let normal_step_circle_scale = ''
        let normal_calorie_circle_scale = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_battery_circle_scale = ''
        let idle_step_circle_scale = ''
        let idle_calorie_circle_scale = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_temperature_icon_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'IMG_9827.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 92,
              y: 250,
              font_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0018.png',
              unit_tc: '0018.png',
              unit_en: '0018.png',
              negative_image: '0017.png',
              invalid_image: '0017.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 102,
              y: 203,
              image_array: ["0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 195,
              // center_y: 323,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 20,
              // line_width: 8,
              // color: 0xFFC0C0C0,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 195,
              // center_y: 323,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 35,
              // line_width: 8,
              // color: 0xFFC0C0C0,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            
            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 195,
              // center_y: 323,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 50,
              // line_width: 8,
              // color: 0xFFC0C0C0,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            
            if (screenType != hmSetting.screen_type.AOD) {
              normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 176,
              y: 93,
              week_en: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png"],
              week_tc: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png"],
              week_sc: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 167,
              day_startY: 118,
              day_sc_array: ["0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
              day_tc_array: ["0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
              day_en_array: ["0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'CHAS.png',
              hour_centerX: 195,
              hour_centerY: 225,
              hour_posX: 11,
              hour_posY: 92,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'MIN.png',
              minute_centerX: 195,
              minute_centerY: 225,
              minute_posX: 9,
              minute_posY: 154,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'STREL.png',
              second_centerX: 195,
              second_centerY: 225,
              second_posX: 10,
              second_posY: 215,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 72,
              y: 173,
              w: 100,
              h: 100,
              src: '0057.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 223,
              y: 173,
              w: 100,
              h: 100,
              src: '0057.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 145,
              y: 271,
              w: 100,
              h: 100,
              src: '0057.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'IMG_9827.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 195,
              // center_y: 323,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 20,
              // line_width: 8,
              // color: 0xFFC0C0C0,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONAL_AOD,
            // });

            
            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 195,
              // center_y: 323,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 35,
              // line_width: 8,
              // color: 0xFFC0C0C0,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONAL_AOD,
            // });

            
            if (screenType == hmSetting.screen_type.AOD) {
              idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };

            // idle_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 195,
              // center_y: 323,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 50,
              // line_width: 8,
              // color: 0xFFC0C0C0,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONAL_AOD,
            // });

            
            if (screenType == hmSetting.screen_type.AOD) {
              idle_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 176,
              y: 93,
              week_en: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png"],
              week_tc: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png"],
              week_sc: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 167,
              day_startY: 118,
              day_sc_array: ["0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
              day_tc_array: ["0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
              day_en_array: ["0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'CHAS.png',
              hour_centerX: 195,
              hour_centerY: 225,
              hour_posX: 11,
              hour_posY: 92,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'MIN.png',
              minute_centerX: 195,
              minute_centerY: 225,
              minute_posX: 9,
              minute_posY: 154,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'IMG_9828.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            function scale_call() {

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale
                  // initial parameters
                  let start_angle_normal_battery = -90;
                  let end_angle_normal_battery = 270;
                  let center_x_normal_battery = 195;
                  let center_y_normal_battery = 323;
                  let radius_normal_battery = 20;
                  let line_width_cs_normal_battery = 8;
                  let color_cs_normal_battery = 0xFFC0C0C0;
                  
                  // calculated parameters
                  let arcX_normal_battery = center_x_normal_battery - radius_normal_battery;
                  let arcY_normal_battery = center_y_normal_battery - radius_normal_battery;
                  let CircleWidth_normal_battery = 2 * radius_normal_battery;
                  let angle_offset_normal_battery = end_angle_normal_battery - start_angle_normal_battery;
                  angle_offset_normal_battery = angle_offset_normal_battery * progress_cs_normal_battery;
                  let end_angle_normal_battery_draw = start_angle_normal_battery + angle_offset_normal_battery;
                  
                  normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_battery,
                    y: arcY_normal_battery,
                    w: CircleWidth_normal_battery,
                    h: CircleWidth_normal_battery,
                    start_angle: start_angle_normal_battery,
                    end_angle: end_angle_normal_battery_draw,
                    color: color_cs_normal_battery,
                    line_width: line_width_cs_normal_battery,
                  });
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale
                  // initial parameters
                  let start_angle_normal_step = -90;
                  let end_angle_normal_step = 270;
                  let center_x_normal_step = 195;
                  let center_y_normal_step = 323;
                  let radius_normal_step = 35;
                  let line_width_cs_normal_step = 8;
                  let color_cs_normal_step = 0xFFC0C0C0;
                  
                  // calculated parameters
                  let arcX_normal_step = center_x_normal_step - radius_normal_step;
                  let arcY_normal_step = center_y_normal_step - radius_normal_step;
                  let CircleWidth_normal_step = 2 * radius_normal_step;
                  let angle_offset_normal_step = end_angle_normal_step - start_angle_normal_step;
                  angle_offset_normal_step = angle_offset_normal_step * progress_cs_normal_step;
                  let end_angle_normal_step_draw = start_angle_normal_step + angle_offset_normal_step;
                  
                  normal_step_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_step,
                    y: arcY_normal_step,
                    w: CircleWidth_normal_step,
                    h: CircleWidth_normal_step,
                    start_angle: start_angle_normal_step,
                    end_angle: end_angle_normal_step_draw,
                    color: color_cs_normal_step,
                    line_width: line_width_cs_normal_step,
                  });
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale
                  // initial parameters
                  let start_angle_normal_calorie = -90;
                  let end_angle_normal_calorie = 270;
                  let center_x_normal_calorie = 195;
                  let center_y_normal_calorie = 323;
                  let radius_normal_calorie = 50;
                  let line_width_cs_normal_calorie = 8;
                  let color_cs_normal_calorie = 0xFFC0C0C0;
                  
                  // calculated parameters
                  let arcX_normal_calorie = center_x_normal_calorie - radius_normal_calorie;
                  let arcY_normal_calorie = center_y_normal_calorie - radius_normal_calorie;
                  let CircleWidth_normal_calorie = 2 * radius_normal_calorie;
                  let angle_offset_normal_calorie = end_angle_normal_calorie - start_angle_normal_calorie;
                  angle_offset_normal_calorie = angle_offset_normal_calorie * progress_cs_normal_calorie;
                  let end_angle_normal_calorie_draw = start_angle_normal_calorie + angle_offset_normal_calorie;
                  
                  normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_calorie,
                    y: arcY_normal_calorie,
                    w: CircleWidth_normal_calorie,
                    h: CircleWidth_normal_calorie,
                    start_angle: start_angle_normal_calorie,
                    end_angle: end_angle_normal_calorie_draw,
                    color: color_cs_normal_calorie,
                    line_width: line_width_cs_normal_calorie,
                  });
                };

                console.log('update scales BATTERY');
                let progress_cs_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale
                  // initial parameters
                  let start_angle_idle_battery = -90;
                  let end_angle_idle_battery = 270;
                  let center_x_idle_battery = 195;
                  let center_y_idle_battery = 323;
                  let radius_idle_battery = 20;
                  let line_width_cs_idle_battery = 8;
                  let color_cs_idle_battery = 0xFFC0C0C0;
                  
                  // calculated parameters
                  let arcX_idle_battery = center_x_idle_battery - radius_idle_battery;
                  let arcY_idle_battery = center_y_idle_battery - radius_idle_battery;
                  let CircleWidth_idle_battery = 2 * radius_idle_battery;
                  let angle_offset_idle_battery = end_angle_idle_battery - start_angle_idle_battery;
                  angle_offset_idle_battery = angle_offset_idle_battery * progress_cs_idle_battery;
                  let end_angle_idle_battery_draw = start_angle_idle_battery + angle_offset_idle_battery;
                  
                  idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_idle_battery,
                    y: arcY_idle_battery,
                    w: CircleWidth_idle_battery,
                    h: CircleWidth_idle_battery,
                    start_angle: start_angle_idle_battery,
                    end_angle: end_angle_idle_battery_draw,
                    color: color_cs_idle_battery,
                    line_width: line_width_cs_idle_battery,
                  });
                };

                console.log('update scales STEP');
                let progress_cs_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale
                  // initial parameters
                  let start_angle_idle_step = -90;
                  let end_angle_idle_step = 270;
                  let center_x_idle_step = 195;
                  let center_y_idle_step = 323;
                  let radius_idle_step = 35;
                  let line_width_cs_idle_step = 8;
                  let color_cs_idle_step = 0xFFC0C0C0;
                  
                  // calculated parameters
                  let arcX_idle_step = center_x_idle_step - radius_idle_step;
                  let arcY_idle_step = center_y_idle_step - radius_idle_step;
                  let CircleWidth_idle_step = 2 * radius_idle_step;
                  let angle_offset_idle_step = end_angle_idle_step - start_angle_idle_step;
                  angle_offset_idle_step = angle_offset_idle_step * progress_cs_idle_step;
                  let end_angle_idle_step_draw = start_angle_idle_step + angle_offset_idle_step;
                  
                  idle_step_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_idle_step,
                    y: arcY_idle_step,
                    w: CircleWidth_idle_step,
                    h: CircleWidth_idle_step,
                    start_angle: start_angle_idle_step,
                    end_angle: end_angle_idle_step_draw,
                    color: color_cs_idle_step,
                    line_width: line_width_cs_idle_step,
                  });
                };

                console.log('update scales CALORIE');
                let progress_cs_idle_calorie = progressCalories;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_calorie_circle_scale
                  // initial parameters
                  let start_angle_idle_calorie = -90;
                  let end_angle_idle_calorie = 270;
                  let center_x_idle_calorie = 195;
                  let center_y_idle_calorie = 323;
                  let radius_idle_calorie = 50;
                  let line_width_cs_idle_calorie = 8;
                  let color_cs_idle_calorie = 0xFFC0C0C0;
                  
                  // calculated parameters
                  let arcX_idle_calorie = center_x_idle_calorie - radius_idle_calorie;
                  let arcY_idle_calorie = center_y_idle_calorie - radius_idle_calorie;
                  let CircleWidth_idle_calorie = 2 * radius_idle_calorie;
                  let angle_offset_idle_calorie = end_angle_idle_calorie - start_angle_idle_calorie;
                  angle_offset_idle_calorie = angle_offset_idle_calorie * progress_cs_idle_calorie;
                  let end_angle_idle_calorie_draw = start_angle_idle_calorie + angle_offset_idle_calorie;
                  
                  idle_calorie_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_idle_calorie,
                    y: arcY_idle_calorie,
                    w: CircleWidth_idle_calorie,
                    h: CircleWidth_idle_calorie,
                    start_angle: start_angle_idle_calorie,
                    end_angle: end_angle_idle_calorie_draw,
                    color: color_cs_idle_calorie,
                    line_width: line_width_cs_idle_calorie,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  