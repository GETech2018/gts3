﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_system_disconnect_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 233,
              y: 356,
              font_array: ["temp10.png","temp11.png","temp12.png","temp13.png","temp14.png","temp15.png","temp16.png","temp17.png","temp18.png","temp19.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'temp30.png',
              unit_tc: 'temp30.png',
              unit_en: 'temp30.png',
              negative_image: 'temp31.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 172,
              y: 341,
              image_array: ["weather0071.png","weather0072.png","weather0073.png","weather0074.png","weather0075.png","weather0076.png","weather0077.png","weather0078.png","weather0079.png","weather0080.png","weather0081.png","weather0082.png","weather0083.png","weather0084.png","weather0085.png","weather0086.png","weather0087.png","weather0088.png","weather0089.png","weather0090.png","weather0091.png","weather0092.png","weather0093.png","weather0094.png","weather0095.png","weather0096.png","weather0097.png","weather0098.png","weather0099.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 298,
              y: 64,
              src: 'status0080.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 67,
              y: 64,
              src: 'status0082.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 180,
              y: 70,
              font_array: ["batery0013.png","batery0014.png","batery0015.png","batery0016.png","batery0017.png","batery0018.png","batery0019.png","batery0020.png","batery0021.png","batery0022.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'batterysignal0048.png',
              unit_tc: 'batterysignal0048.png',
              unit_en: 'batterysignal0048.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 246,
              y: 70,
              image_array: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 219,
              month_startY: 280,
              month_sc_array: ["months0023.png","months0024.png","months0025.png","months0026.png","months0027.png","months0028.png","months0029.png","months0030.png","months0031.png","months0032.png","months0033.png","months0034.png"],
              month_tc_array: ["months0023.png","months0024.png","months0025.png","months0026.png","months0027.png","months0028.png","months0029.png","months0030.png","months0031.png","months0032.png","months0033.png","months0034.png"],
              month_en_array: ["months0023.png","months0024.png","months0025.png","months0026.png","months0027.png","months0028.png","months0029.png","months0030.png","months0031.png","months0032.png","months0033.png","months0034.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 174,
              day_startY: 282,
              day_sc_array: ["days0035.png","days0036.png","days0037.png","days0038.png","days0039.png","days0040.png","days0041.png","days0042.png","days0043.png","days0044.png"],
              day_tc_array: ["days0035.png","days0036.png","days0037.png","days0038.png","days0039.png","days0040.png","days0041.png","days0042.png","days0043.png","days0044.png"],
              day_en_array: ["days0035.png","days0036.png","days0037.png","days0038.png","days0039.png","days0040.png","days0041.png","days0042.png","days0043.png","days0044.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 71,
              y: 287,
              week_en: ["week0045.png","week0046.png","week0047.png","week0048.png","week0049.png","week0050.png","week0051.png"],
              week_tc: ["week0045.png","week0046.png","week0047.png","week0048.png","week0049.png","week0050.png","week0051.png"],
              week_sc: ["week0045.png","week0046.png","week0047.png","week0048.png","week0049.png","week0050.png","week0051.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 79,
              hour_startY: 100,
              hour_array: ["digital0002.png","digital0003.png","digital0004.png","digital0005.png","digital0006.png","digital0007.png","digital0008.png","digital0009.png","digital0010.png","digital0011.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 206,
              minute_startY: 100,
              minute_array: ["digital0002.png","digital0003.png","digital0004.png","digital0005.png","digital0006.png","digital0007.png","digital0008.png","digital0009.png","digital0010.png","digital0011.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 186,
              y: 100,
              src: 'digital0012.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0004.png',
              hour_centerX: 195,
              hour_centerY: 225,
              hour_posX: 30,
              hour_posY: 114,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0003.png',
              minute_centerX: 195,
              minute_centerY: 225,
              minute_posX: 30,
              minute_posY: 180,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0005.png',
              second_centerX: 195,
              second_centerY: 225,
              second_posX: 12,
              second_posY: 181,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 268,
              y: 64,
              src: 'status0080.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'aod1-0004.png',
              hour_centerX: 195,
              hour_centerY: 225,
              hour_posX: 30,
              hour_posY: 114,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'aod1-0003.png',
              minute_centerX: 195,
              minute_centerY: 225,
              minute_posX: 30,
              minute_posY: 180,
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  