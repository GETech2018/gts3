﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_pai_circle_scale = ''
        let normal_calorie_circle_scale = ''
        let normal_heart_rate_circle_scale = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_text_text_img = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_date_img_date_week_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_hour = ''

        //dynamic modify end

        let secondPic = null;
        let now = null;
        let timer_sec_anim = null;
        let lastTime = 0;
        let animDuration = 5000;
        var secAnim = {
            "anim_rate": 'linear',
            "anim_duration": animDuration,
            "anim_from": 0,
            "anim_to": 360,
            "repeat_count": 1,
            "anim_fps": 25,
            "anim_key": "angle",
            "anim_status": 1,
        }
        /**
         * 在合适的层级调用此方法即可
         */
        function setSec() {
            if (now == null) {
                now = hmSensor.createSensor(hmSensor.id.TIME);
            }
            var screenType = hmSetting.getScreenType();
            if (screenType == hmSetting.screen_type.AOD) {
                stopSecAnim();
            } else {
                secondPic = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 390,
                    h: 450,
                    pos_x: 390 / 2 - 45,
                    pos_y: 450 / 2 - 218,
                    center_x: 195,
                    center_y: 225,
                    src:  "4.png",
                    angle: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                })
            }
            var vDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                resume_call: (function () {//划入表盘
                    console.log('ui resume');
                    if (timer_sec_anim != null && timer_sec_anim != 0) return;
                    let duration = now.utc - lastTime;
                    if (duration < animDuration) {
                        duration = animDuration - duration;
                    } else {
                        duration = 0;
                    }
                    timer_sec_anim = timer.createTimer(duration, animDuration, (function (option) {
                        lastTime = now.utc;
                        startSecAnim();
                    }));
                }),
                pause_call: (function () {
                    console.log('ui pause');
                    stopSecAnim();
                }),
            });
        }

        function startSecAnim() {
            let sec = now.second * 6;
            secAnim["anim_from"] = sec;
            secAnim["anim_to"] = sec + animDuration * 6 / 1000;

            secondPic.setProperty(hmUI.prop.ANIM, secAnim);
        }

        /**
         * onDestroy()中要调用一下这个方法
         */
        function stopSecAnim() {
            timer.stopTimer(timer_sec_anim);
            timer_sec_anim = 0;
        }

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: '0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 209,
              y: 59,
              src: 'heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 130,
              font_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '6.png',
              center_x: 223,
              center_y: 106,
              x: 28,
              y: 67,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 210,
              y: 301,
              src: 'step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 187,
              y: 369,
              font_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '6.png',
              center_x: 224,
              center_y: 347,
              x: 28,
              y: 67,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '6.png',
              center_x: 99,
              center_y: 227,
              x: 28,
              y: 67,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 306,
              y: 269,
              week_en: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              week_tc: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              week_sc: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 345,
              month_startY: 166,
              month_sc_array: ["ACT_FONT_01.png","ACT_FONT_02.png","ACT_FONT_03.png","ACT_FONT_04.png","ACT_FONT_05.png","ACT_FONT_06.png","ACT_FONT_07.png","ACT_FONT_08.png","ACT_FONT_09.png","ACT_FONT_10.png"],
              month_tc_array: ["ACT_FONT_01.png","ACT_FONT_02.png","ACT_FONT_03.png","ACT_FONT_04.png","ACT_FONT_05.png","ACT_FONT_06.png","ACT_FONT_07.png","ACT_FONT_08.png","ACT_FONT_09.png","ACT_FONT_10.png"],
              month_en_array: ["ACT_FONT_01.png","ACT_FONT_02.png","ACT_FONT_03.png","ACT_FONT_04.png","ACT_FONT_05.png","ACT_FONT_06.png","ACT_FONT_07.png","ACT_FONT_08.png","ACT_FONT_09.png","ACT_FONT_10.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 310,
              day_startY: 166,
              day_sc_array: ["ACT_FONT_01.png","ACT_FONT_02.png","ACT_FONT_03.png","ACT_FONT_04.png","ACT_FONT_05.png","ACT_FONT_06.png","ACT_FONT_07.png","ACT_FONT_08.png","ACT_FONT_09.png","ACT_FONT_10.png"],
              day_tc_array: ["ACT_FONT_01.png","ACT_FONT_02.png","ACT_FONT_03.png","ACT_FONT_04.png","ACT_FONT_05.png","ACT_FONT_06.png","ACT_FONT_07.png","ACT_FONT_08.png","ACT_FONT_09.png","ACT_FONT_10.png"],
              day_en_array: ["ACT_FONT_01.png","ACT_FONT_02.png","ACT_FONT_03.png","ACT_FONT_04.png","ACT_FONT_05.png","ACT_FONT_06.png","ACT_FONT_07.png","ACT_FONT_08.png","ACT_FONT_09.png","ACT_FONT_10.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 336,
              y: 168,
              src: 'ACT_FONT_12.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 264,
              hour_startY: 208,
              hour_array: ["006.png","007.png","008.png","009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 325,
              minute_startY: 208,
              minute_array: ["006.png","007.png","008.png","009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 312,
              y: 210,
              src: '0016.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '2.png',
              hour_centerX: 195,
              hour_centerY: 225,
              hour_posX: 45,
              hour_posY: 197,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '3.png',
              minute_centerX: 195,
              minute_centerY: 225,
              minute_posX: 51,
              minute_posY: 219,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {

            });

            setSec();



            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 306,
              y: 269,
              week_en: ["Week_ico_001.png","Week_ico_002.png","Week_ico_003.png","Week_ico_004.png","Week_ico_005.png","Week_ico_006.png","Week_ico_007.png"],
              week_tc: ["Week_ico_001.png","Week_ico_002.png","Week_ico_003.png","Week_ico_004.png","Week_ico_005.png","Week_ico_006.png","Week_ico_007.png"],
              week_sc: ["Week_ico_001.png","Week_ico_002.png","Week_ico_003.png","Week_ico_004.png","Week_ico_005.png","Week_ico_006.png","Week_ico_007.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 345,
              month_startY: 166,
              month_sc_array: ["ACT_FOT_001.png","ACT_FOT_002.png","ACT_FOT_003.png","ACT_FOT_004.png","ACT_FOT_005.png","ACT_FOT_006.png","ACT_FOT_007.png","ACT_FOT_008.png","ACT_FOT_009.png","ACT_FOT_010.png"],
              month_tc_array: ["ACT_FOT_001.png","ACT_FOT_002.png","ACT_FOT_003.png","ACT_FOT_004.png","ACT_FOT_005.png","ACT_FOT_006.png","ACT_FOT_007.png","ACT_FOT_008.png","ACT_FOT_009.png","ACT_FOT_010.png"],
              month_en_array: ["ACT_FOT_001.png","ACT_FOT_002.png","ACT_FOT_003.png","ACT_FOT_004.png","ACT_FOT_005.png","ACT_FOT_006.png","ACT_FOT_007.png","ACT_FOT_008.png","ACT_FOT_009.png","ACT_FOT_010.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 310,
              day_startY: 166,
              day_sc_array: ["ACT_FOT_001.png","ACT_FOT_002.png","ACT_FOT_003.png","ACT_FOT_004.png","ACT_FOT_005.png","ACT_FOT_006.png","ACT_FOT_007.png","ACT_FOT_008.png","ACT_FOT_009.png","ACT_FOT_010.png"],
              day_tc_array: ["ACT_FOT_001.png","ACT_FOT_002.png","ACT_FOT_003.png","ACT_FOT_004.png","ACT_FOT_005.png","ACT_FOT_006.png","ACT_FOT_007.png","ACT_FOT_008.png","ACT_FOT_009.png","ACT_FOT_010.png"],
              day_en_array: ["ACT_FOT_001.png","ACT_FOT_002.png","ACT_FOT_003.png","ACT_FOT_004.png","ACT_FOT_005.png","ACT_FOT_006.png","ACT_FOT_007.png","ACT_FOT_008.png","ACT_FOT_009.png","ACT_FOT_010.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 336,
              y: 168,
              src: 'ACT_FONT_012.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 264,
              hour_startY: 208,
              hour_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 325,
              minute_startY: 208,
              minute_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 312,
              y: 210,
              src: '37.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '2.png',
              hour_centerX: 195,
              hour_centerY: 225,
              hour_posX: 45,
              hour_posY: 197,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '3.png',
              minute_centerX: 195,
              minute_centerY: 225,
              minute_posX: 51,
              minute_posY: 219,
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  