
    /*
    ** huamiOS bundle tool v1.0.17
    * *huamiOS watchface js version v1.0.1
    * *Copyright © Huami. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start
        let normal$_$background$_$bg = ''
        let normal$_$week$_$week = ''
        let normal$_$digital_clock$_$img_time = ''
        let idle$_$week$_$week = ''
        let idle$_$digital_clock$_$img_time = ''
        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            normal$_$background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$week$_$week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 89,
              y: 160,
              week_en: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png"],
              week_tc: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png"],
              week_sc: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$digital_clock$_$img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_zero: 1,
              hour_startX: 86,
              hour_startY: 79,
              hour_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              hour_space: 0,
              hour_unit_sc: '19.png',
              hour_unit_tc: '19.png',
              hour_unit_en: '19.png',
              hour_align: hmUI.align.RIGHT,
              minute_zero: 1,
              minute_startX: 207,
              minute_startY: 79,
              minute_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              minute_space: 0,
              minute_align: hmUI.align.LEFT,
              minute_follow: 0,
              am_x: 182,
              am_y: 50,
              am_sc_path: '20.png',
              am_en_path: '21.png',
              pm_x: 182,
              pm_y: 50,
              pm_sc_path: '22.png',
              pm_en_path: '23.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            idle$_$week$_$week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 89,
              y: 254,
              week_en: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png"],
              week_tc: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png"],
              week_sc: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });
  
                    
            idle$_$digital_clock$_$img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_zero: 1,
              hour_startX: 86,
              hour_startY: 173,
              hour_array: ["31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png"],
              hour_space: 0,
              hour_unit_sc: '41.png',
              hour_unit_tc: '41.png',
              hour_unit_en: '41.png',
              hour_align: hmUI.align.RIGHT,
              minute_zero: 1,
              minute_startX: 207,
              minute_startY: 173,
              minute_array: ["31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png"],
              minute_space: 0,
              minute_align: hmUI.align.LEFT,
              minute_follow: 0,
              am_x: 182,
              am_y: 144,
              am_sc_path: '42.png',
              am_en_path: '43.png',
              pm_x: 182,
              pm_y: 144,
              pm_sc_path: '44.png',
              pm_en_path: '45.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  