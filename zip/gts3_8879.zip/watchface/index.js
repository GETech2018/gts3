﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time = ''
        let idle_temperature_icon_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -50,
              hour_startY: 22,
              hour_array: ["000.png","001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png"],
              hour_zero: 1,
              hour_space: -18,
              hour_align: hmUI.align.LEFT,

              minute_startX: -50,
              minute_startY: 199,
              minute_array: ["0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png"],
              minute_zero: 1,
              minute_space: -18,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 277,
              y: 171,
              src: 'IMG_9588.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 280,
              y: 147,
              w: 71,
              h: 161,
              src: '000057.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -50,
              hour_startY: 22,
              hour_array: ["000.png","001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png"],
              hour_zero: 1,
              hour_space: -18,
              hour_align: hmUI.align.LEFT,

              minute_startX: -50,
              minute_startY: 199,
              minute_array: ["0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png"],
              minute_zero: 1,
              minute_space: -18,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'IMG_9589.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  