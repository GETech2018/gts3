﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_linear_scale = ''
        let normal_rotate_animation_img_1 = '';
        let normal_rotate_animation_param_1 = null;
        let normal_rotate_animation_lastTime_1 = 0;
        let timer_anim_rotate_1;
        let normal_rotate_animation_count_1 = 0;
        let normal_rotate_animation_img_2 = '';
        let normal_rotate_animation_param_2 = null;
        let normal_rotate_animation_lastTime_2 = 0;
        let timer_anim_rotate_2;
        let normal_rotate_animation_count_2 = 0;
        let normal_rotate_animation_img_3 = '';
        let normal_rotate_animation_param_3 = null;
        let normal_rotate_animation_lastTime_3 = 0;
        let timer_anim_rotate_3;
        let normal_rotate_animation_count_3 = 0;
        let normal_rotate_animation_img_4 = '';
        let normal_rotate_animation_param_4 = null;
        let normal_rotate_animation_lastTime_4 = 0;
        let timer_anim_rotate_4;
        let normal_rotate_animation_count_4 = 0;
        let normal_rotate_animation_img_5 = '';
        let normal_rotate_animation_param_5 = null;
        let normal_rotate_animation_lastTime_5 = 0;
        let timer_anim_rotate_5;
        let normal_rotate_animation_count_5 = 0;
        let normal_temperature_icon_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 296,
              // start_y: 396,
              // color: 0xFF2F314D,
              // lenght: -326,
              // line_width: 92,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_rotate_animation_img_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 391,
              h: 451,
              pos_x: 62,
              pos_y: 91,
              center_x: 195,
              center_y: 223,
              angle: 0,
              src: 'animation/anim_4.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_1 = {
              anim_rate: 'linear',
              anim_duration: 10000,
              anim_from: 0,
              anim_to: 360,
              anim_fps: 15,
              anim_key: "angle",
            };

            let now = hmSensor.createSensor(hmSensor.id.TIME);

            function anim_rotate_1_complete_call() {
              normal_rotate_animation_count_1 = normal_rotate_animation_count_1 - 1;
              if(normal_rotate_animation_count_1 < -1) normal_rotate_animation_count_1 = - 1;
                normal_rotate_animation_img_1.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_1);
                normal_rotate_animation_lastTime_1 = now.utc;
              if(normal_rotate_animation_count_1 == 0) stop_anim_rotate_1();
            }; // end animation callback function
            
            function stop_anim_rotate_1() {
              if (timer_anim_rotate_1) {
                timer.stopTimer(timer_anim_rotate_1);
                timer_anim_rotate_1 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_1 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 360,
              // pos_x: 133,
              // pos_y: 132,
              // center_x: 195,
              // center_y: 223,
              // src: 'anim_4.png',
              // anim_fps: 15,
              // anim_duration: 10000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_2 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 391,
              h: 451,
              pos_x: 0,
              pos_y: 0,
              center_x: 0,
              center_y: 0,
              angle: 0,
              src: 'animation/anim_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_2 = {
              anim_rate: 'linear',
              anim_duration: 999000,
              anim_from: 0,
              anim_to: 0,
              anim_fps: 1,
              anim_key: "angle",
            };

            function anim_rotate_2_complete_call() {
              normal_rotate_animation_count_2 = normal_rotate_animation_count_2 - 1;
              if(normal_rotate_animation_count_2 < -1) normal_rotate_animation_count_2 = - 1;
                normal_rotate_animation_img_2.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_2);
                normal_rotate_animation_lastTime_2 = now.utc;
              if(normal_rotate_animation_count_2 == 0) stop_anim_rotate_2();
            }; // end animation callback function
            
            function stop_anim_rotate_2() {
              if (timer_anim_rotate_2) {
                timer.stopTimer(timer_anim_rotate_2);
                timer_anim_rotate_2 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_2 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 0,
              // pos_x: 0,
              // pos_y: 0,
              // center_x: 0,
              // center_y: 0,
              // src: 'anim_2.png',
              // anim_fps: 1,
              // anim_duration: 999000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_3 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 391,
              h: 451,
              pos_x: 14,
              pos_y: 224,
              center_x: 59,
              center_y: 268,
              angle: 0,
              src: 'animation/anim_8.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_3 = {
              anim_rate: 'linear',
              anim_duration: 10000,
              anim_from: 0,
              anim_to: 360,
              anim_fps: 15,
              anim_key: "angle",
            };

            function anim_rotate_3_complete_call() {
              normal_rotate_animation_count_3 = normal_rotate_animation_count_3 - 1;
              if(normal_rotate_animation_count_3 < -1) normal_rotate_animation_count_3 = - 1;
                normal_rotate_animation_img_3.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_3);
                normal_rotate_animation_lastTime_3 = now.utc;
              if(normal_rotate_animation_count_3 == 0) stop_anim_rotate_3();
            }; // end animation callback function
            
            function stop_anim_rotate_3() {
              if (timer_anim_rotate_3) {
                timer.stopTimer(timer_anim_rotate_3);
                timer_anim_rotate_3 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_3 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 360,
              // pos_x: 45,
              // pos_y: 44,
              // center_x: 59,
              // center_y: 268,
              // src: 'anim_8.png',
              // anim_fps: 15,
              // anim_duration: 10000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_4 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 391,
              h: 451,
              pos_x: 205,
              pos_y: 93,
              center_x: 257,
              center_y: 151,
              angle: 0,
              src: 'animation/anim_10.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_4 = {
              anim_rate: 'linear',
              anim_duration: 10000,
              anim_from: 0,
              anim_to: 360,
              anim_fps: 15,
              anim_key: "angle",
            };

            function anim_rotate_4_complete_call() {
              normal_rotate_animation_count_4 = normal_rotate_animation_count_4 - 1;
              if(normal_rotate_animation_count_4 < -1) normal_rotate_animation_count_4 = - 1;
                normal_rotate_animation_img_4.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_4);
                normal_rotate_animation_lastTime_4 = now.utc;
              if(normal_rotate_animation_count_4 == 0) stop_anim_rotate_4();
            }; // end animation callback function
            
            function stop_anim_rotate_4() {
              if (timer_anim_rotate_4) {
                timer.stopTimer(timer_anim_rotate_4);
                timer_anim_rotate_4 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_4 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 360,
              // pos_x: 52,
              // pos_y: 58,
              // center_x: 257,
              // center_y: 151,
              // src: 'anim_10.png',
              // anim_fps: 15,
              // anim_duration: 10000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_5 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 391,
              h: 451,
              pos_x: -5,
              pos_y: 138,
              center_x: 40,
              center_y: 182,
              angle: 0,
              src: 'animation/anim_8.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_5 = {
              anim_rate: 'linear',
              anim_duration: 10000,
              anim_from: 0,
              anim_to: 360,
              anim_fps: 15,
              anim_key: "angle",
            };

            function anim_rotate_5_complete_call() {
              normal_rotate_animation_count_5 = normal_rotate_animation_count_5 - 1;
              if(normal_rotate_animation_count_5 < -1) normal_rotate_animation_count_5 = - 1;
                normal_rotate_animation_img_5.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_5);
                normal_rotate_animation_lastTime_5 = now.utc;
              if(normal_rotate_animation_count_5 == 0) stop_anim_rotate_5();
            }; // end animation callback function
            
            function stop_anim_rotate_5() {
              if (timer_anim_rotate_5) {
                timer.stopTimer(timer_anim_rotate_5);
                timer_anim_rotate_5 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_5 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 360,
              // pos_x: 45,
              // pos_y: 44,
              // center_x: 40,
              // center_y: 182,
              // src: 'anim_8.png',
              // anim_fps: 15,
              // anim_duration: 10000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 125,
              y: 22,
              week_en: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png"],
              week_tc: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png"],
              week_sc: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 173,
              day_startY: 37,
              day_sc_array: ["000.png","001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png"],
              day_tc_array: ["000.png","001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png"],
              day_en_array: ["000.png","001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 148,
              hour_startY: 381,
              hour_array: ["000.png","001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_unit_sc: '0010.png',
              hour_unit_tc: '0010.png',
              hour_unit_en: '0010.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["000.png","001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '13.png',
              hour_centerX: 195,
              hour_centerY: 225,
              hour_posX: 73,
              hour_posY: 176,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '14.png',
              minute_centerX: 195,
              minute_centerY: 225,
              minute_posX: 69,
              minute_posY: 222,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '15.png',
              second_centerX: 195,
              second_centerY: 225,
              second_posX: 60,
              second_posY: 235,
              second_cover_path: '16.png',
              second_cover_x: 154,
              second_cover_y: 183,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 125,
              y: 22,
              week_en: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png"],
              week_tc: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png"],
              week_sc: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 173,
              day_startY: 37,
              day_sc_array: ["000.png","001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png"],
              day_tc_array: ["000.png","001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png"],
              day_en_array: ["000.png","001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 148,
              hour_startY: 381,
              hour_array: ["000.png","001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_unit_sc: '0010.png',
              hour_unit_tc: '0010.png',
              hour_unit_en: '0010.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["000.png","001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '13S.png',
              hour_centerX: 195,
              hour_centerY: 225,
              hour_posX: 73,
              hour_posY: 176,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '14S.png',
              minute_centerX: 195,
              minute_centerY: 225,
              minute_posX: 69,
              minute_posY: 222,
              minute_cover_path: '16.png',
              minute_cover_x: 154,
              minute_cover_y: 183,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            function scale_call() {

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 296;
                  let start_y_normal_battery = 396;
                  let lenght_ls_normal_battery = -326;
                  let line_width_ls_normal_battery = 92;
                  let color_ls_normal_battery = 0xFF2F314D;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = line_width_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = lenght_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    line_width_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_y_normal_battery_draw = start_y_normal_battery_draw - line_width_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();

                let nawAnimationTime = now.utc;;
                
                let delay_anim_rotate_1 = 0;
                let repeat_anim_rotate_1 = 10000;
                delay_anim_rotate_1 = repeat_anim_rotate_1 - (nawAnimationTime - normal_rotate_animation_lastTime_1);
                if(delay_anim_rotate_1 < 0) delay_anim_rotate_1 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_1) > repeat_anim_rotate_1) {
                  normal_rotate_animation_count_1 = 0;
                  timer_anim_rotate_1_mirror = false;
                };

                if (!timer_anim_rotate_1) {
                  timer_anim_rotate_1 = timer.createTimer(delay_anim_rotate_1, repeat_anim_rotate_1, (function (option) {
                    anim_rotate_1_complete_call()
                  })); // end timer create
                };
                
                let delay_anim_rotate_2 = 0;
                let repeat_anim_rotate_2 = 999000;
                delay_anim_rotate_2 = repeat_anim_rotate_2 - (nawAnimationTime - normal_rotate_animation_lastTime_2);
                if(delay_anim_rotate_2 < 0) delay_anim_rotate_2 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_2) > repeat_anim_rotate_2) {
                  normal_rotate_animation_count_2 = 0;
                  timer_anim_rotate_2_mirror = false;
                };

                if (!timer_anim_rotate_2) {
                  timer_anim_rotate_2 = timer.createTimer(delay_anim_rotate_2, repeat_anim_rotate_2, (function (option) {
                    anim_rotate_2_complete_call()
                  })); // end timer create
                };
                
                let delay_anim_rotate_3 = 0;
                let repeat_anim_rotate_3 = 10000;
                delay_anim_rotate_3 = repeat_anim_rotate_3 - (nawAnimationTime - normal_rotate_animation_lastTime_3);
                if(delay_anim_rotate_3 < 0) delay_anim_rotate_3 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_3) > repeat_anim_rotate_3) {
                  normal_rotate_animation_count_3 = 0;
                  timer_anim_rotate_3_mirror = false;
                };

                if (!timer_anim_rotate_3) {
                  timer_anim_rotate_3 = timer.createTimer(delay_anim_rotate_3, repeat_anim_rotate_3, (function (option) {
                    anim_rotate_3_complete_call()
                  })); // end timer create
                };
                
                let delay_anim_rotate_4 = 0;
                let repeat_anim_rotate_4 = 10000;
                delay_anim_rotate_4 = repeat_anim_rotate_4 - (nawAnimationTime - normal_rotate_animation_lastTime_4);
                if(delay_anim_rotate_4 < 0) delay_anim_rotate_4 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_4) > repeat_anim_rotate_4) {
                  normal_rotate_animation_count_4 = 0;
                  timer_anim_rotate_4_mirror = false;
                };

                if (!timer_anim_rotate_4) {
                  timer_anim_rotate_4 = timer.createTimer(delay_anim_rotate_4, repeat_anim_rotate_4, (function (option) {
                    anim_rotate_4_complete_call()
                  })); // end timer create
                };
                
                let delay_anim_rotate_5 = 0;
                let repeat_anim_rotate_5 = 10000;
                delay_anim_rotate_5 = repeat_anim_rotate_5 - (nawAnimationTime - normal_rotate_animation_lastTime_5);
                if(delay_anim_rotate_5 < 0) delay_anim_rotate_5 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_5) > repeat_anim_rotate_5) {
                  normal_rotate_animation_count_5 = 0;
                  timer_anim_rotate_5_mirror = false;
                };

                if (!timer_anim_rotate_5) {
                  timer_anim_rotate_5 = timer.createTimer(delay_anim_rotate_5, repeat_anim_rotate_5, (function (option) {
                    anim_rotate_5_complete_call()
                  })); // end timer create
                };

              }),
              pause_call: (function () {
                stop_anim_rotate_1();
                stop_anim_rotate_2();
                stop_anim_rotate_3();
                stop_anim_rotate_4();
                stop_anim_rotate_5();

              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  