﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_heart_rate_TextCircle = new Array(5);
        let normal_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextCircle_img_width = 20;
        let normal_heart_rate_TextCircle_img_height = 30;
        let normal_heart_rate_TextCircle_unit = null;
        let normal_heart_rate_TextCircle_unit_width = 32;
        let normal_heart_rate_TextCircle_error_img_width = 20;
        let normal_uvi_pointer_progress_img_pointer = ''
        let normal_uvi_text_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_humidity_pointer_progress_img_pointer = ''
        let normal_step_icon_img = ''
        let normal_step_circle_scale = ''
        let normal_step_target_TextCircle = new Array(5);
        let normal_step_target_TextCircle_ASCIIARRAY = new Array(10);
        let normal_step_target_TextCircle_img_width = 20;
        let normal_step_target_TextCircle_img_height = 30;
        let normal_battery_icon_img = ''
        let normal_battery_circle_scale = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_analog_clock_pro_minute_cover_pointer_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_pro_second_cover_pointer_img = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'color_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_rate_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 195,
              // circle_center_Y: 225,
              // font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              // radius: 236,
              // angle: 144,
              // char_space_angle: 0,
              // unit: 'heart.png',
              // error_image: '0022.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextCircle_ASCIIARRAY[0] = '0011.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[1] = '0012.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[2] = '0013.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[3] = '0014.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[4] = '0015.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[5] = '0016.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[6] = '0017.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[7] = '0018.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[8] = '0019.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[9] = '0020.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 195,
                center_y: 225,
                pos_x: 195 - normal_heart_rate_TextCircle_img_width / 2,
                pos_y: 225 + 206,
                src: '0011.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_heart_rate_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              center_x: 195,
              center_y: 225,
              pos_x: 195 - normal_heart_rate_TextCircle_unit_width / 2,
              pos_y: 225 + 206,
              src: 'heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_heart_rate_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_uvi_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'wponto_22222.png',
              center_x: 196,
              center_y: 224,
              x: 0,
              y: 203,
              start_angle: 15,
              end_angle: 48,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 304,
              y: 25,
              font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              padding: false,
              h_space: -6,
              angle: 45,
              invalid_image: '0066.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 28,
              y: 46,
              font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              padding: false,
              h_space: -6,
              angle: -38,
              unit_sc: '0023.png',
              unit_tc: '0023.png',
              unit_en: '0023.png',
              negative_image: '0022.png',
              invalid_image: '0022.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 146,
              y: 15,
              font_array: ["m0.fw.png","m1.fw.png","m2.fw.png","m3.fw.png","m4.fw.png","m5.fw.png","m6.fw.png","m7.fw.png","m8.fw.png","m9.fw.png"],
              padding: false,
              h_space: -8,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 15,
              y: 101,
              font_array: ["m0.fw.png","m1.fw.png","m2.fw.png","m3.fw.png","m4.fw.png","m5.fw.png","m6.fw.png","m7.fw.png","m8.fw.png","m9.fw.png"],
              padding: false,
              h_space: -8,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 185,
              y: 415,
              src: 'BLUETOOTH.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'wponto_22222.png',
              center_x: 196,
              center_y: 224,
              x: 0,
              y: 204,
              start_angle: 308,
              end_angle: 342,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 16,
              y: 310,
              src: 'PASSOS.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 195,
              // center_y: 226,
              // start_angle: 192,
              // end_angle: 238,
              // radius: 201,
              // line_width: 9,
              // line_cap: Rounded,
              // color: 0xFFC0C0C0,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 195,
              center_y: 226,
              start_angle: 192,
              end_angle: 238,
              radius: 197,
              line_width: 9,
              corner_flag: 0,
              color: 0xFFC0C0C0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_step_target_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 195,
              // circle_center_Y: 225,
              // font_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              // radius: 221,
              // angle: 216,
              // char_space_angle: -1,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.STEP_TARGET,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_target_TextCircle_ASCIIARRAY[0] = '0011.png';  // set of images with numbers
            normal_step_target_TextCircle_ASCIIARRAY[1] = '0012.png';  // set of images with numbers
            normal_step_target_TextCircle_ASCIIARRAY[2] = '0013.png';  // set of images with numbers
            normal_step_target_TextCircle_ASCIIARRAY[3] = '0014.png';  // set of images with numbers
            normal_step_target_TextCircle_ASCIIARRAY[4] = '0015.png';  // set of images with numbers
            normal_step_target_TextCircle_ASCIIARRAY[5] = '0016.png';  // set of images with numbers
            normal_step_target_TextCircle_ASCIIARRAY[6] = '0017.png';  // set of images with numbers
            normal_step_target_TextCircle_ASCIIARRAY[7] = '0018.png';  // set of images with numbers
            normal_step_target_TextCircle_ASCIIARRAY[8] = '0019.png';  // set of images with numbers
            normal_step_target_TextCircle_ASCIIARRAY[9] = '0020.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_target_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 195,
                center_y: 225,
                pos_x: 195 - normal_step_target_TextCircle_img_width / 2,
                pos_y: 225 + 206,
                src: '0011.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_target_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 365,
              y: 305,
              src: 'battery.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 195,
              // center_y: 225,
              // start_angle: 170,
              // end_angle: 123,
              // radius: 201,
              // line_width: 9,
              // line_cap: Rounded,
              // color: 0xFFC5C5C5,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 195,
              center_y: 225,
              start_angle: 170,
              end_angle: 123,
              radius: 197,
              line_width: 9,
              corner_flag: 0,
              color: 0xFFC5C5C5,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              time_update(true, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '0069S.png',
              // center_x: 195,
              // center_y: 225,
              // x: 29,
              // y: 113,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 195 - 29,
              pos_y: 225 - 113,
              center_x: 195,
              center_y: 225,
              src: '0069S.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '0070S.png',
              // center_x: 195,
              // center_y: 225,
              // x: 30,
              // y: 180,
              // start_angle: 0,
              // end_angle: 360,
              // cover_path: '5.png',
              // cover_x: 186,
              // cover_y: 217,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 195 - 30,
              pos_y: 225 - 180,
              center_x: 195,
              center_y: 225,
              src: '0070S.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_pro_minute_cover_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 186,
              y: 217,
              src: '5.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '22.png',
              // center_x: 195,
              // center_y: 225,
              // x: 13,
              // y: 182,
              // start_angle: 0,
              // end_angle: 360,
              // cover_path: '5.png',
              // cover_x: 186,
              // cover_y: 217,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 195 - 13,
              pos_y: 225 - 182,
              center_x: 195,
              center_y: 225,
              src: '22.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_pro_second_cover_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 186,
              y: 217,
              src: '5.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: '101.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0069S.png',
              hour_centerX: 195,
              hour_centerY: 225,
              hour_posX: 29,
              hour_posY: 113,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0070S.png',
              minute_centerX: 195,
              minute_centerY: 225,
              minute_posX: 30,
              minute_posY: 180,
              minute_cover_path: '5.png',
              minute_cover_x: 186,
              minute_cover_y: 215,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 18,
              y: 0,
              w: 100,
              h: 100,
              src: '00057.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 160,
              y: 186,
              w: 70,
              h: 70,
              src: '00057.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 261,
              y: 0,
              w: 100,
              h: 100,
              src: '00057.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 93,
              y: 256,
              w: 60,
              h: 60,
              src: '00057.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 165,
              y: 286,
              w: 60,
              h: 60,
              src: '00057.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 8,
              y: 372,
              w: 100,
              h: 100,
              src: '00057.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function time_update(updateHour = false, updateMinute = false) {
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) {
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*minute/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*second/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

            };

            function text_update() {

              console.log('update text circle HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_circle_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_heart_rate_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 324;
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_circle_string.length > 0 && normal_heart_rate_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_heart_rate_TextCircle_img_angle = 0;
                  let normal_heart_rate_TextCircle_dot_img_angle = 0;
                  let normal_heart_rate_TextCircle_unit_angle = 0;
                  normal_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(normal_heart_rate_TextCircle_img_width/2, 236));
                  normal_heart_rate_TextCircle_unit_angle = toDegree(Math.atan2(normal_heart_rate_TextCircle_unit_width/2, 236));
                  // alignment = CENTER_H
                  let normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_img_angle * (normal_heart_rate_circle_string.length - 1);
                  normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_angleOffset + (normal_heart_rate_TextCircle_img_angle + normal_heart_rate_TextCircle_unit_angle + 0) / 2;
                  normal_heart_rate_TextCircle_angleOffset = -normal_heart_rate_TextCircle_angleOffset;
                  char_Angle -= normal_heart_rate_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_heart_rate_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_heart_rate_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 195 - normal_heart_rate_TextCircle_img_width / 2);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextCircle_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_heart_rate_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= normal_heart_rate_TextCircle_unit_angle;
                  normal_heart_rate_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_heart_rate_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_heart_rate_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_heart_rate_TextCircle[0].setProperty(hmUI.prop.POS_X, 195 - normal_heart_rate_TextCircle_error_img_width / 2);
                  normal_heart_rate_TextCircle[0].setProperty(hmUI.prop.SRC, '0022.png');
                  normal_heart_rate_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle STEP');
              let targetStep = step.target;
              let normal_step_target_circle_string = parseInt(targetStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_target_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 396;
                if (targetStep != null && targetStep != undefined && isFinite(targetStep) && normal_step_target_circle_string.length > 0 && normal_step_target_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_step_target_TextCircle_img_angle = 0;
                  let normal_step_target_TextCircle_dot_img_angle = 0;
                  normal_step_target_TextCircle_img_angle = toDegree(Math.atan2(normal_step_target_TextCircle_img_width/2, 221));
                  // alignment = CENTER_H
                  let normal_step_target_TextCircle_angleOffset = normal_step_target_TextCircle_img_angle * (normal_step_target_circle_string.length - 1);
                  normal_step_target_TextCircle_angleOffset = normal_step_target_TextCircle_angleOffset + -1 * (normal_step_target_circle_string.length - 1) / 2;
                  normal_step_target_TextCircle_angleOffset = -normal_step_target_TextCircle_angleOffset;
                  char_Angle -= normal_step_target_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_step_target_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_step_target_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_step_target_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_step_target_TextCircle[index].setProperty(hmUI.prop.POS_X, 195 - normal_step_target_TextCircle_img_width / 2);
                      normal_step_target_TextCircle[index].setProperty(hmUI.prop.SRC, normal_step_target_TextCircle_ASCIIARRAY[charCode]);
                      normal_step_target_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_step_target_TextCircle_img_angle + -1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            function scale_call() {

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 195,
                      center_y: 226,
                      start_angle: 192,
                      end_angle: 238,
                      radius: 197,
                      line_width: 9,
                      corner_flag: 0,
                      color: 0xFFC0C0C0,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 195,
                      center_y: 225,
                      start_angle: 170,
                      end_angle: 123,
                      radius: 197,
                      line_width: 9,
                      corner_flag: 0,
                      color: 0xFFC5C5C5,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                time_update(true, true);
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}