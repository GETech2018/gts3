/*
** Facemaker bundle tool v0.0.1
* *huamiOS watchface js version v1.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_background_bg_img0 = '';
		let normal_date_current_date_monthday2 = '';
		let normal_date_img_date_week_img3 = '';
		let normal_battery_current_text_img5 = '';
		let normal_battery_image_progress_img_level6 = '';
		let normal_digital_clock_img_hour8 = '';
		let normal_digital_clock_img_minute9 = '';
		let normal_background_bg_img10 = '';
		let normal_digital_clock_img_second11 = '';
		let normal_analog_clock_time_pointer_hour13 = '';
		let normal_analog_clock_time_pointer_minute14 = '';
		let normal_analog_clock_time_pointer_second_sweep15 = '';
		let lastTime = 0;
		let animTimer;
		const animDuration = 5000;
		const animFps = 25;

		function startSecAnim(sec) {
			const secAnim = {
				anim_rate: 'linear',
				anim_duration: animDuration,
				anim_from: sec,
				anim_to: sec + animDuration * 6 / 1000,
				repeat_count: 1,
				anim_fps: animFps,
				anim_key: 'angle',
				anim_status: 1,
			}
			normal_analog_clock_time_pointer_second_sweep15.setProperty(hmUI.prop.ANIM, secAnim);
		}

		function stopSecAnim() {
			if (animTimer) {
				timer.stopTimer(animTimer);
				animTimer = undefined;
			}
		}

		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				let screenType = hmSetting.getScreenType();

				normal_background_bg_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 398,
					h: 450,
					src: '0002.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_current_date_monthday2 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 344,
					day_startY: 216,
					day_sc_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
					day_tc_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
					day_en_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
					day_zero: true,
					day_space: 0,
					day_align: hmUI.align.LEFT,
					day_is_character: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_img_date_week_img3 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 265,
					y: 215,
					week_en: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png"],
					week_tc: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png"],
					week_sc: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png"],
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_current_text_img5 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 83,
					y: 282,
					font_array: ["0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png"],
					padding: false,
					h_space: 0,
					unit_sc: '0030.png',
					unit_tc: '0030.png',
					unit_en: '0030.png',
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_image_progress_img_level6 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 84,
					y: 310,
					image_array: ["0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png"],
					image_length: 7,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_digital_clock_img_hour8 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 115,
					hour_startY: 282,
					hour_array: ["0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.LEFT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_digital_clock_img_minute9 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 210,
					minute_startY: 282,
					minute_array: ["0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img10 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 192,
					y: 270,
					w: 14,
					h: 117,
					src: '0058.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_digital_clock_img_second11 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 291,
					second_startY: 325,
					second_array: ["0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.LEFT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_analog_clock_time_pointer_hour13 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					hour_path: '0069.png',
					hour_centerX: 195,
					hour_centerY: 225,
					hour_posX: 18,
					hour_posY: 132,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_analog_clock_time_pointer_minute14 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					minute_path: '0070.png',
					minute_centerX: 196,
					minute_centerY: 225,
					minute_posX: 16,
					minute_posY: 195,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				normal_analog_clock_time_pointer_second_sweep15 = normal_analog_clock_time_pointer_second_sweep15 || hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 390,
					h: 450,
					center_x: 195,
					center_y: 225,
					pos_x: 180,
					pos_y: 36,
					src: '0071.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
					let duration = 0;
					const diffTime = timeSensor.utc - lastTime;
					if (diffTime < animDuration) {
						duration = animDuration - diffTime;
					}
					animTimer = timer.createTimer(duration, animDuration, (function (option) {
						lastTime = timeSensor.utc;
						startSecAnim(timeSensor.second * 6);
						}));
					}),
					pause_call: (function () {
						stopSecAnim();
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
						stopSecAnim();
		},
	});	})()
} catch (e) {
	console.log(e)
}