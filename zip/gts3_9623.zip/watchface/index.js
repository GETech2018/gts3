﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_pai_day_text_img = ''
        let normal_uvi_text_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: '100.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 330,
              y: 250,
              font_array: ["0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 26,
              y: 250,
              font_array: ["0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 171,
              y: 80,
              font_array: ["0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'number_du.png',
              unit_tc: 'number_du.png',
              unit_en: 'number_du.png',
              negative_image: 'fuhao.png',
              invalid_image: 'none.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 179,
              y: 40,
              image_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 206,
              year_startY: 273,
              year_sc_array: ["00013.png","00014.png","00015.png","00016.png","00017.png","00018.png","00019.png","00020.png","00021.png","00022.png"],
              year_tc_array: ["00013.png","00014.png","00015.png","00016.png","00017.png","00018.png","00019.png","00020.png","00021.png","00022.png"],
              year_en_array: ["00013.png","00014.png","00015.png","00016.png","00017.png","00018.png","00019.png","00020.png","00021.png","00022.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 165,
              month_startY: 273,
              month_sc_array: ["00013.png","00014.png","00015.png","00016.png","00017.png","00018.png","00019.png","00020.png","00021.png","00022.png"],
              month_tc_array: ["00013.png","00014.png","00015.png","00016.png","00017.png","00018.png","00019.png","00020.png","00021.png","00022.png"],
              month_en_array: ["00013.png","00014.png","00015.png","00016.png","00017.png","00018.png","00019.png","00020.png","00021.png","00022.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: '112.png',
              month_unit_tc: '112.png',
              month_unit_en: '112.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 122,
              day_startY: 273,
              day_sc_array: ["00013.png","00014.png","00015.png","00016.png","00017.png","00018.png","00019.png","00020.png","00021.png","00022.png"],
              day_tc_array: ["00013.png","00014.png","00015.png","00016.png","00017.png","00018.png","00019.png","00020.png","00021.png","00022.png"],
              day_en_array: ["00013.png","00014.png","00015.png","00016.png","00017.png","00018.png","00019.png","00020.png","00021.png","00022.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: '112.png',
              day_unit_tc: '112.png',
              day_unit_en: '112.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 291,
              y: 351,
              font_array: ["00013.png","00014.png","00015.png","00016.png","00017.png","00018.png","00019.png","00020.png","00021.png","00022.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 37,
              y: 351,
              font_array: ["00013.png","00014.png","00015.png","00016.png","00017.png","00018.png","00019.png","00020.png","00021.png","00022.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 291,
              y: 90,
              font_array: ["00013.png","00014.png","00015.png","00016.png","00017.png","00018.png","00019.png","00020.png","00021.png","00022.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 50,
              y: 90,
              font_array: ["00013.png","00014.png","00015.png","00016.png","00017.png","00018.png","00019.png","00020.png","00021.png","00022.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 90,
              y: 148,
              week_en: ["101.png","102.png","103.png","104.png","105.png","106.png","107.png"],
              week_tc: ["101.png","102.png","103.png","104.png","105.png","106.png","107.png"],
              week_sc: ["101.png","102.png","103.png","104.png","105.png","106.png","107.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 101,
              hour_startY: 204,
              hour_array: ["000.png","001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_unit_sc: '111.png',
              hour_unit_tc: '111.png',
              hour_unit_en: '111.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: -32,
              y: 193,
              w: 100,
              h: 100,
              src: '000057.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 147,
              y: 23,
              w: 100,
              h: 100,
              src: '000057.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 23,
              y: 28,
              w: 100,
              h: 100,
              src: '000057.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 22,
              y: 343,
              w: 100,
              h: 100,
              src: '000057.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 206,
              year_startY: 273,
              year_sc_array: ["00013.png","00014.png","00015.png","00016.png","00017.png","00018.png","00019.png","00020.png","00021.png","00022.png"],
              year_tc_array: ["00013.png","00014.png","00015.png","00016.png","00017.png","00018.png","00019.png","00020.png","00021.png","00022.png"],
              year_en_array: ["00013.png","00014.png","00015.png","00016.png","00017.png","00018.png","00019.png","00020.png","00021.png","00022.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 165,
              month_startY: 273,
              month_sc_array: ["00013.png","00014.png","00015.png","00016.png","00017.png","00018.png","00019.png","00020.png","00021.png","00022.png"],
              month_tc_array: ["00013.png","00014.png","00015.png","00016.png","00017.png","00018.png","00019.png","00020.png","00021.png","00022.png"],
              month_en_array: ["00013.png","00014.png","00015.png","00016.png","00017.png","00018.png","00019.png","00020.png","00021.png","00022.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: '112.png',
              month_unit_tc: '112.png',
              month_unit_en: '112.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 122,
              day_startY: 273,
              day_sc_array: ["00013.png","00014.png","00015.png","00016.png","00017.png","00018.png","00019.png","00020.png","00021.png","00022.png"],
              day_tc_array: ["00013.png","00014.png","00015.png","00016.png","00017.png","00018.png","00019.png","00020.png","00021.png","00022.png"],
              day_en_array: ["00013.png","00014.png","00015.png","00016.png","00017.png","00018.png","00019.png","00020.png","00021.png","00022.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: '112.png',
              day_unit_tc: '112.png',
              day_unit_en: '112.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 90,
              y: 148,
              week_en: ["101.png","102.png","103.png","104.png","105.png","106.png","107.png"],
              week_tc: ["101.png","102.png","103.png","104.png","105.png","106.png","107.png"],
              week_sc: ["101.png","102.png","103.png","104.png","105.png","106.png","107.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 101,
              hour_startY: 204,
              hour_array: ["000.png","001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_unit_sc: '111.png',
              hour_unit_tc: '111.png',
              hour_unit_en: '111.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["000.png","001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  