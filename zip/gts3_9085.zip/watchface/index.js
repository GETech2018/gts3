﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_year = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_distance_text_text_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 21,
              hour_startY: 114,
              hour_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              hour_zero: 1,
              hour_space: 10,
              hour_align: hmUI.align.LEFT,

              minute_startX: 229,
              minute_startY: 114,
              minute_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              minute_zero: 1,
              minute_space: 8,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 183,
              y: 103,
              src: '22.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 43,
              y: 21,
              src: '23.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 82,
              y: 22,
              src: '24.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 70,
              day_startY: 66,
              day_sc_array: ["46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png"],
              day_tc_array: ["46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png"],
              day_en_array: ["46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png"],
              day_zero: 1,
              day_space: 2,
              day_unit_sc: '56.png',
              day_unit_tc: '56.png',
              day_unit_en: '56.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 125,
              month_startY: 66,
              month_sc_array: ["35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png"],
              month_tc_array: ["35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png"],
              month_en_array: ["35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png"],
              month_zero: 1,
              month_space: 2,
              month_unit_sc: '45.png',
              month_unit_tc: '45.png',
              month_unit_en: '45.png',
              month_align: hmUI.align.RIGHT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 179,
              year_startY: 66,
              year_sc_array: ["25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png"],
              year_tc_array: ["25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png"],
              year_en_array: ["25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 273,
              y: 60,
              font_array: ["64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png"],
              padding: false,
              h_space: 3,
              unit_sc: '74.png',
              unit_tc: '74.png',
              unit_en: '74.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 248,
              y: 60,
              image_array: ["75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 265,
              y: 287,
              font_array: ["85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png"],
              padding: false,
              h_space: 4,
              negative_image: '96.png',
              invalid_image: '95.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 203,
              y: 284,
              image_array: ["98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png","110.png","111.png","112.png","113.png","114.png","115.png","116.png","117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png","125.png","126.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 85,
              y: 347,
              font_array: ["127.png","128.png","129.png","130.png","131.png","132.png","133.png","134.png","135.png","136.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 27,
              y: 342,
              src: '137.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 88,
              y: 287,
              font_array: ["138.png","139.png","140.png","141.png","142.png","143.png","144.png","145.png","146.png","147.png"],
              padding: false,
              h_space: 0,
              invalid_image: '148.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 24,
              y: 283,
              src: '149.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 213,
              y: 346,
              font_array: ["127.png","128.png","129.png","130.png","131.png","132.png","133.png","134.png","135.png","136.png"],
              padding: false,
              h_space: 3,
              unit_sc: '151.png',
              unit_tc: '151.png',
              unit_en: '151.png',
              dot_image: '150.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 25,
              hour_startY: 106,
              hour_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              hour_zero: 1,
              hour_space: 10,
              hour_unit_sc: '153.png',
              hour_unit_tc: '153.png',
              hour_unit_en: '153.png',
              hour_align: hmUI.align.RIGHT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  