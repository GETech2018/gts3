﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_step_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: '24.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 245,
              y: 355,
              font_array: ["digi_gina_greysmall_6_0000.png","digi_gina_greysmall_6_0001.png","digi_gina_greysmall_6_0002.png","digi_gina_greysmall_6_0003.png","digi_gina_greysmall_6_0004.png","digi_gina_greysmall_6_0005.png","digi_gina_greysmall_6_0006.png","digi_gina_greysmall_6_0007.png","digi_gina_greysmall_6_0008.png","digi_gina_greysmall_6_0009.png"],
              padding: false,
              h_space: -55,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 278,
              y: 406,
              font_array: ["digi_gina_grey5small_0001.png","digi_gina_grey5small_0002.png","digi_gina_grey5small_0003.png","digi_gina_grey5small_0004.png","digi_gina_grey5small_0005.png","digi_gina_grey5small_0006.png","digi_gina_grey5small_0007.png","digi_gina_grey5small_0008.png","digi_gina_grey5small_0009.png","digi_gina_grey5small_0010.png"],
              padding: false,
              h_space: -25,
              unit_sc: 'digi_gina_grey5small_0011.png',
              unit_tc: 'digi_gina_grey5small_0011.png',
              unit_en: 'digi_gina_grey5small_0011.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 25,
              day_startY: 342,
              day_sc_array: ["digi_gina_grey12medium_0001.png","digi_gina_grey12medium_0002.png","digi_gina_grey12medium_0003.png","digi_gina_grey12medium_0004.png","digi_gina_grey12medium_0005.png","digi_gina_grey12medium_0006.png","digi_gina_grey12medium_0007.png","digi_gina_grey12medium_0008.png","digi_gina_grey12medium_0009.png","digi_gina_grey12medium_0010.png"],
              day_tc_array: ["digi_gina_grey12medium_0001.png","digi_gina_grey12medium_0002.png","digi_gina_grey12medium_0003.png","digi_gina_grey12medium_0004.png","digi_gina_grey12medium_0005.png","digi_gina_grey12medium_0006.png","digi_gina_grey12medium_0007.png","digi_gina_grey12medium_0008.png","digi_gina_grey12medium_0009.png","digi_gina_grey12medium_0010.png"],
              day_en_array: ["digi_gina_grey12medium_0001.png","digi_gina_grey12medium_0002.png","digi_gina_grey12medium_0003.png","digi_gina_grey12medium_0004.png","digi_gina_grey12medium_0005.png","digi_gina_grey12medium_0006.png","digi_gina_grey12medium_0007.png","digi_gina_grey12medium_0008.png","digi_gina_grey12medium_0009.png","digi_gina_grey12medium_0010.png"],
              day_zero: 1,
              day_space: -59,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 40,
              month_startY: 390,
              month_sc_array: ["digi_gina_month_5_0013.png","digi_gina_month_5_0014.png","digi_gina_month_5_0015.png","digi_gina_month_5_0016.png","digi_gina_month_5_0017.png","digi_gina_month_5_0018.png","digi_gina_month_5_0019.png","digi_gina_month_5_0020.png","digi_gina_month_5_0021.png","digi_gina_month_5_0022.png","digi_gina_month_5_0023.png","digi_gina_month_5_0024.png"],
              month_tc_array: ["digi_gina_month_5_0013.png","digi_gina_month_5_0014.png","digi_gina_month_5_0015.png","digi_gina_month_5_0016.png","digi_gina_month_5_0017.png","digi_gina_month_5_0018.png","digi_gina_month_5_0019.png","digi_gina_month_5_0020.png","digi_gina_month_5_0021.png","digi_gina_month_5_0022.png","digi_gina_month_5_0023.png","digi_gina_month_5_0024.png"],
              month_en_array: ["digi_gina_month_5_0013.png","digi_gina_month_5_0014.png","digi_gina_month_5_0015.png","digi_gina_month_5_0016.png","digi_gina_month_5_0017.png","digi_gina_month_5_0018.png","digi_gina_month_5_0019.png","digi_gina_month_5_0020.png","digi_gina_month_5_0021.png","digi_gina_month_5_0022.png","digi_gina_month_5_0023.png","digi_gina_month_5_0024.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 110,
              hour_startY: 375,
              hour_array: ["digi_gina_grey12medium_0001.png","digi_gina_grey12medium_0002.png","digi_gina_grey12medium_0003.png","digi_gina_grey12medium_0004.png","digi_gina_grey12medium_0005.png","digi_gina_grey12medium_0006.png","digi_gina_grey12medium_0007.png","digi_gina_grey12medium_0008.png","digi_gina_grey12medium_0009.png","digi_gina_grey12medium_0010.png"],
              hour_zero: 1,
              hour_space: -63,
              hour_align: hmUI.align.LEFT,

              minute_startX: 177,
              minute_startY: 375,
              minute_array: ["digi_gina_grey12medium_0001.png","digi_gina_grey12medium_0002.png","digi_gina_grey12medium_0003.png","digi_gina_grey12medium_0004.png","digi_gina_grey12medium_0005.png","digi_gina_grey12medium_0006.png","digi_gina_grey12medium_0007.png","digi_gina_grey12medium_0008.png","digi_gina_grey12medium_0009.png","digi_gina_grey12medium_0010.png"],
              minute_zero: 1,
              minute_space: -63,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 159,
              y: 370,
              src: 'digi_gina_grey12medium_0011.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0001.png',
              hour_centerX: 195,
              hour_centerY: 195,
              hour_posX: 23,
              hour_posY: 122,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0002.png',
              minute_centerX: 195,
              minute_centerY: 195,
              minute_posX: 23,
              minute_posY: 175,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Picture26.png',
              second_centerX: 195,
              second_centerY: 195,
              second_posX: 11,
              second_posY: 170,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 390,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 110,
              hour_startY: 375,
              hour_array: ["digi_gina_grey12medium_0001.png","digi_gina_grey12medium_0002.png","digi_gina_grey12medium_0003.png","digi_gina_grey12medium_0004.png","digi_gina_grey12medium_0005.png","digi_gina_grey12medium_0006.png","digi_gina_grey12medium_0007.png","digi_gina_grey12medium_0008.png","digi_gina_grey12medium_0009.png","digi_gina_grey12medium_0010.png"],
              hour_zero: 1,
              hour_space: -63,
              hour_align: hmUI.align.LEFT,

              minute_startX: 177,
              minute_startY: 375,
              minute_array: ["digi_gina_grey12medium_0001.png","digi_gina_grey12medium_0002.png","digi_gina_grey12medium_0003.png","digi_gina_grey12medium_0004.png","digi_gina_grey12medium_0005.png","digi_gina_grey12medium_0006.png","digi_gina_grey12medium_0007.png","digi_gina_grey12medium_0008.png","digi_gina_grey12medium_0009.png","digi_gina_grey12medium_0010.png"],
              minute_zero: 1,
              minute_space: -63,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 159,
              y: 370,
              src: 'digi_gina_grey12medium_0011.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
