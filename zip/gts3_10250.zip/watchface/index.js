﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let editBg = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_temperature_icon_img = ''
        let editableTimePointers = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 390,
              // h: 450,
              // AOD_show: True,
              bg_config: [
                { id: 1, preview: 'bg_1.png', path: 'bg_1.png' },
                { id: 2, preview: 'bg_2.png', path: 'bg_2.png' },
                { id: 3, preview: 'bg_3.png', path: 'bg_3.png' },
                { id: 4, preview: 'bg_4.png', path: 'bg_4.png' },
                { id: 5, preview: 'bg_5.png', path: 'bg_5.png' },
              ],
              count: 5,
              default_id: 1,
              fg: 'mask.png',
              tips_bg: 'tips.png',
              tips_x: 135,
              tips_y: 273,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 273,
              y: 217,
              week_en: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png"],
              week_tc: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png"],
              week_sc: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 330,
              day_startY: 217,
              day_sc_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              day_tc_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              day_en_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 273,
              y: 217,
              week_en: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png"],
              week_tc: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png"],
              week_sc: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 330,
              day_startY: 217,
              day_sc_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              day_tc_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              day_en_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'IMG_3157.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, {
              edit_id: 1003,
              x: 0,
              y: 0,
              config: [
                {
                  id: 1,
                  second: {
                    centerX: 195,
                    centerY: 225,
                    posX: 60,
                    posY: 225,
                    path: 'sec_1.png',
                  },
                  hour: {
                    centerX: 195,
                    centerY: 225,
                    posX: 60,
                    posY: 225,
                    path: 'h_1.png',
                  },
                  minute: {
                    centerX: 195,
                    centerY: 225,
                    posX: 61,
                    posY: 225,
                    path: 'm_1.png',
                  },
                  preview: 'pointer_edit_1_preview1.png',
                },
                {
                  id: 2,
                  second: {
                    centerX: 195,
                    centerY: 225,
                    posX: 60,
                    posY: 225,
                    path: 'sec_2.png',
                  },
                  hour: {
                    centerX: 195,
                    centerY: 225,
                    posX: 60,
                    posY: 225,
                    path: 'h_2.png',
                  },
                  minute: {
                    centerX: 195,
                    centerY: 225,
                    posX: 61,
                    posY: 225,
                    path: 'm_2.png',
                  },
                  preview: 'pointer_edit_2_preview1.png',
                },
                {
                  id: 3,
                  second: {
                    centerX: 195,
                    centerY: 225,
                    posX: 60,
                    posY: 225,
                    path: 'sec_3.png',
                  },
                  hour: {
                    centerX: 195,
                    centerY: 225,
                    posX: 60,
                    posY: 225,
                    path: 'h_3.png',
                  },
                  minute: {
                    centerX: 195,
                    centerY: 225,
                    posX: 61,
                    posY: 225,
                    path: 'm_3.png',
                  },
                  preview: 'pointer_edit_3_preview1.png',
                },
                {
                  id: 4,
                  second: {
                    centerX: 195,
                    centerY: 225,
                    posX: 60,
                    posY: 225,
                    path: 'sec_4.png',
                  },
                  hour: {
                    centerX: 195,
                    centerY: 225,
                    posX: 60,
                    posY: 225,
                    path: 'h_4.png',
                  },
                  minute: {
                    centerX: 195,
                    centerY: 225,
                    posX: 61,
                    posY: 225,
                    path: 'm_4.png',
                  },
                  preview: 'pointer_edit_4_preview1.png',
                },
                {
                  id: 5,
                  second: {
                    centerX: 195,
                    centerY: 225,
                    posX: 60,
                    posY: 225,
                    path: 'sec_5.png',
                  },
                  hour: {
                    centerX: 195,
                    centerY: 225,
                    posX: 60,
                    posY: 225,
                    path: 'h_5.png',
                  },
                  minute: {
                    centerX: 195,
                    centerY: 225,
                    posX: 61,
                    posY: 225,
                    path: 'm_5.png',
                  },
                  preview: 'pointer_edit_5_preview1.png',
                },
              ],
              count: 5,
              default_id: 1,
              fg: 'mask.png',
              tips_x: 135,
              tips_y: 52,
              tips_bg: 'tips.png',
            });
            const screenTypeForETP = hmSetting.getScreenType();
            const aodModel = screenTypeForETP == hmSetting.screen_type.AOD;
            const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, !aodModel);
            editableTimePointers = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
