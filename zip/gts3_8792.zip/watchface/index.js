﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_date_img_date_week_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
          
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: '0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
	    const hour_1 = hmUI.createWidget(hmUI.widget.IMG)
                    hour_1.setProperty(hmUI.prop.MORE,{
                        x: 0,
                        y: 0,
                        src:  "1.png",
                    });
		  const hour_2 = hmUI.createWidget(hmUI.widget.IMG)
                  hour_2.setProperty(hmUI.prop.MORE,{
                        x: 0,
                        y: 0,
                        src:  "2.png",
                    });
		  const hour_3 = hmUI.createWidget(hmUI.widget.IMG)
                    hour_3.setProperty(hmUI.prop.MORE,{
                        x: 0,
                        y: 0,
                        src:  "3.png",
                    });
		  const hour_4 = hmUI.createWidget(hmUI.widget.IMG)
                    hour_4.setProperty(hmUI.prop.MORE,{
                        x: 0,
                        y: 0,
                        src:  "4.png",
                    });
		  const hour_5 = hmUI.createWidget(hmUI.widget.IMG)
                    hour_5.setProperty(hmUI.prop.MORE,{
                        x: 0,
                        y: 0,
                        src:  "5.png",
                    });
		  const hour_6 = hmUI.createWidget(hmUI.widget.IMG)
                    hour_6.setProperty(hmUI.prop.MORE,{
                        x: 0,
                        y: 0,
                        src:  "6.png",
                    });
		  const hour_7 = hmUI.createWidget(hmUI.widget.IMG)
                    hour_7.setProperty(hmUI.prop.MORE,{
                        x: 0,
                        y: 0,
                        src:  "7.png",
                    });
		  const hour_8 = hmUI.createWidget(hmUI.widget.IMG)
                    hour_8.setProperty(hmUI.prop.MORE,{
                        x: 0,
                        y: 0,
                        src:  "8.png",
                    });
		  const hour_9 = hmUI.createWidget(hmUI.widget.IMG)
                    hour_9.setProperty(hmUI.prop.MORE,{
                        x: 0,
                        y: 0,
                        src:  "9.png",
                    });
		  const hour_10 = hmUI.createWidget(hmUI.widget.IMG)
                    hour_10.setProperty(hmUI.prop.MORE,{
                        x: 0,
                        y: 0,
                        src:  "10.png",
                    });
		  const hour_11 = hmUI.createWidget(hmUI.widget.IMG)
                    hour_11.setProperty(hmUI.prop.MORE,{
                        x: 0,
                        y: 0,
                        src:  "11.png",
                    });
		  const hour_12 = hmUI.createWidget(hmUI.widget.IMG)
                    hour_12.setProperty(hmUI.prop.MORE,{
                        x: 0,
                        y: 0,
                        src:  "12.png",
                    });
                    hour_12.setProperty(hmUI.prop.VISIBLE,false);
                    hour_11.setProperty(hmUI.prop.VISIBLE,false);
                    hour_10.setProperty(hmUI.prop.VISIBLE,false);
                    hour_9.setProperty(hmUI.prop.VISIBLE,false);
                    hour_8.setProperty(hmUI.prop.VISIBLE,false);
                    hour_7.setProperty(hmUI.prop.VISIBLE,false);
                    hour_6.setProperty(hmUI.prop.VISIBLE,false);
                    hour_5.setProperty(hmUI.prop.VISIBLE,false);
                    hour_4.setProperty(hmUI.prop.VISIBLE,false);
                    hour_3.setProperty(hmUI.prop.VISIBLE,false);
                    hour_2.setProperty(hmUI.prop.VISIBLE,false);
                    hour_1.setProperty(hmUI.prop.VISIBLE,false);

  // change_background
	let now;
	now = hmSensor.createSensor(hmSensor.id.TIME);
	switch (now.hour) {
		case 1: hour_1.setProperty(hmUI.prop.VISIBLE,true); break;
		case 2: hour_2.setProperty(hmUI.prop.VISIBLE,true); break;
		case 3: hour_3.setProperty(hmUI.prop.VISIBLE,true); break;
 		case 4: hour_4.setProperty(hmUI.prop.VISIBLE,true); break;
  		case 5: hour_5.setProperty(hmUI.prop.VISIBLE,true); break;
 		case 6: hour_6.setProperty(hmUI.prop.VISIBLE,true); break;
		case 7: hour_7.setProperty(hmUI.prop.VISIBLE,true); break;
 		case 8: hour_8.setProperty(hmUI.prop.VISIBLE,true); break; 
  		case 9: hour_9.setProperty(hmUI.prop.VISIBLE,true); break;
 		case 10: hour_10.setProperty(hmUI.prop.VISIBLE,true); break;
		case 11: hour_11.setProperty(hmUI.prop.VISIBLE,true); break;
 		case 12: hour_12.setProperty(hmUI.prop.VISIBLE,true); break;
		case 13: hour_1.setProperty(hmUI.prop.VISIBLE,true); break;
		case 14: hour_2.setProperty(hmUI.prop.VISIBLE,true); break;
		case 15: hour_3.setProperty(hmUI.prop.VISIBLE,true); break;
 		case 16: hour_4.setProperty(hmUI.prop.VISIBLE,true); break;
  		case 17: hour_5.setProperty(hmUI.prop.VISIBLE,true); break;
 		case 18: hour_6.setProperty(hmUI.prop.VISIBLE,true); break;
		case 19: hour_7.setProperty(hmUI.prop.VISIBLE,true); break;
 		case 20: hour_8.setProperty(hmUI.prop.VISIBLE,true); break; 
  		case 21: hour_9.setProperty(hmUI.prop.VISIBLE,true); break;
 		case 22: hour_10.setProperty(hmUI.prop.VISIBLE,true); break;
		case 23: hour_11.setProperty(hmUI.prop.VISIBLE,true); break;
 		case 0: hour_12.setProperty(hmUI.prop.VISIBLE,true); break;
		}
	let diffTime = 1;
	const timer1 = timer.createTimer(
	0,
	1000,
  	function (option) {
		if (now.hour != diffTime) {
                    hour_12.setProperty(hmUI.prop.VISIBLE,false);
                    hour_11.setProperty(hmUI.prop.VISIBLE,false);
                    hour_10.setProperty(hmUI.prop.VISIBLE,false);
                    hour_9.setProperty(hmUI.prop.VISIBLE,false);
                    hour_8.setProperty(hmUI.prop.VISIBLE,false);
                    hour_7.setProperty(hmUI.prop.VISIBLE,false);
                    hour_6.setProperty(hmUI.prop.VISIBLE,false);
                    hour_5.setProperty(hmUI.prop.VISIBLE,false);
                    hour_4.setProperty(hmUI.prop.VISIBLE,false);
                    hour_3.setProperty(hmUI.prop.VISIBLE,false);
                    hour_2.setProperty(hmUI.prop.VISIBLE,false);
                    hour_1.setProperty(hmUI.prop.VISIBLE,false);
	switch (now.hour) {
		case 1: hour_1.setProperty(hmUI.prop.VISIBLE,true); break;
		case 2: hour_2.setProperty(hmUI.prop.VISIBLE,true); break;
		case 3: hour_3.setProperty(hmUI.prop.VISIBLE,true); break;
 		case 4: hour_4.setProperty(hmUI.prop.VISIBLE,true); break;
  		case 5: hour_5.setProperty(hmUI.prop.VISIBLE,true); break;
 		case 6: hour_6.setProperty(hmUI.prop.VISIBLE,true); break;
		case 7: hour_7.setProperty(hmUI.prop.VISIBLE,true); break;
 		case 8: hour_8.setProperty(hmUI.prop.VISIBLE,true); break; 
  		case 9: hour_9.setProperty(hmUI.prop.VISIBLE,true); break;
 		case 10: hour_10.setProperty(hmUI.prop.VISIBLE,true); break;
		case 11: hour_11.setProperty(hmUI.prop.VISIBLE,true); break;
 		case 12: hour_12.setProperty(hmUI.prop.VISIBLE,true); break;
		case 13: hour_1.setProperty(hmUI.prop.VISIBLE,true); break;
		case 14: hour_2.setProperty(hmUI.prop.VISIBLE,true); break;
		case 15: hour_3.setProperty(hmUI.prop.VISIBLE,true); break;
 		case 16: hour_4.setProperty(hmUI.prop.VISIBLE,true); break;
  		case 17: hour_5.setProperty(hmUI.prop.VISIBLE,true); break;
 		case 18: hour_6.setProperty(hmUI.prop.VISIBLE,true); break;
		case 19: hour_7.setProperty(hmUI.prop.VISIBLE,true); break;
 		case 20: hour_8.setProperty(hmUI.prop.VISIBLE,true); break; 
  		case 21: hour_9.setProperty(hmUI.prop.VISIBLE,true); break;
 		case 22: hour_10.setProperty(hmUI.prop.VISIBLE,true); break;
		case 23: hour_11.setProperty(hmUI.prop.VISIBLE,true); break;
 		case 0: hour_12.setProperty(hmUI.prop.VISIBLE,true); break;
		}
			diffTime = now.hour;
		}
  	},
	)
  // -----
             let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 165,
              y: 318,
              font_array: ["0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 210,
              day_startY: 137,
              day_sc_array: ["0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png"],
              day_tc_array: ["0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png"],
              day_en_array: ["0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 193,
              y: 136,
              src: '0093.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 138,
              y: 136,
              week_en: ["0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
              week_tc: ["0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
              week_sc: ["0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '68.png',
              hour_centerX: 195,
              hour_centerY: 225,
              hour_posX: 22,
              hour_posY: 99,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '66.png',
              minute_centerX: 195,
              minute_centerY: 225,
              minute_posX: 25,
              minute_posY: 170,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '67.png',
              second_centerX: 195,
              second_centerY: 225,
              second_posX: 11,
              second_posY: 162,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: '0.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

    	    idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 210,
              day_startY: 137,
              day_sc_array: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
              day_tc_array: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
              day_en_array: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 193,
              y: 136,
              src: '0094.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 138,
              y: 136,
              week_en: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              week_tc: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              week_sc: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '70.png',
              hour_centerX: 195,
              hour_centerY: 225,
              hour_posX: 22,
              hour_posY: 99,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '69.png',
              minute_centerX: 195,
              minute_centerY: 225,
              minute_posX: 25,
              minute_posY: 170,
              show_level: hmUI.show_level.ONAL_AOD,
            });

      function scale_call() {

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale
                  // initial parameters
                  let start_angle_normal_battery = -90;
                  let end_angle_normal_battery = 270;
                  let center_x_normal_battery = 195;
                  let center_y_normal_battery = 330;
                  let radius_normal_battery = 39;
                  let line_width_cs_normal_battery = 8;
                  let color_cs_normal_battery = 0xFFEB1465;
                  
                  // calculated parameters
                  let arcX_normal_battery = center_x_normal_battery - radius_normal_battery;
                  let arcY_normal_battery = center_y_normal_battery - radius_normal_battery;
                  let CircleWidth_normal_battery = 2 * radius_normal_battery;
                  let angle_offset_normal_battery = end_angle_normal_battery - start_angle_normal_battery;
                  angle_offset_normal_battery = angle_offset_normal_battery * progress_cs_normal_battery;
                  let end_angle_normal_battery_draw = start_angle_normal_battery + angle_offset_normal_battery;
                  
                  normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_battery,
                    y: arcY_normal_battery,
                    w: CircleWidth_normal_battery,
                    h: CircleWidth_normal_battery,
                    start_angle: start_angle_normal_battery,
                    end_angle: end_angle_normal_battery_draw,
                    color: color_cs_normal_battery,
                    line_width: line_width_cs_normal_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  