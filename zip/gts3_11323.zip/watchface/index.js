﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let editBg = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_current_separator_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_icon_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_text_text_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 390,
              // h: 450,
              // AOD_show: True,
              bg_config: [
                { id: 1, preview: 'Background_1.png', path: 'Background_1.png' },
                { id: 2, preview: 'Background_2.png', path: 'Background_2.png' },
                { id: 3, preview: 'Background_3.png', path: 'Background_3.png' },
                { id: 4, preview: 'Background_4.png', path: 'Background_4.png' },
                { id: 5, preview: 'Background_5.png', path: 'Background_5.png' },
                { id: 6, preview: 'Background_6.png', path: 'Background_6.png' },
                { id: 7, preview: 'Background_7.png', path: 'Background_7.png' },
                { id: 8, preview: 'Background_8.png', path: 'Background_8.png' },
                { id: 9, preview: 'Background_9.png', path: 'Background_9.png' },
              ],
              count: 9,
              default_id: 1,
              fg: '.png',
              tips_bg: '.png',
              tips_x: 92,
              tips_y: 407,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 75,
              y: 360,
              w: 255,
              h: 30,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 119,
              y: 61,
              font_array: ["sn_0000_0.png","sn_0001_1.png","sn_0002_2.png","sn_0003_3.png","sn_0004_4.png","sn_0005_5.png","sn_0006_6.png","sn_0007_7.png","sn_0008_8.png","sn_0009_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0075.png',
              unit_tc: '0075.png',
              unit_en: '0075.png',
              negative_image: '0076.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 96,
              y: 58,
              src: 'Thermometre.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 225,
              y: 45,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_0n.png","w_14n.png","w_1n.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 160,
              y: 405,
              src: 'battery.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 162,
              // start_y: 431,
              // color: 0xFFFFFFFF,
              // lenght: -21,
              // line_width: 12,
              // line_cap: Flat,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 190,
              y: 408,
              font_array: ["sn_0000_0.png","sn_0001_1.png","sn_0002_2.png","sn_0003_3.png","sn_0004_4.png","sn_0005_5.png","sn_0006_6.png","sn_0007_7.png","sn_0008_8.png","sn_0009_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'percent.png',
              unit_tc: 'percent.png',
              unit_en: 'percent.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 222,
              y: 14,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 179,
              y: 14,
              src: 'sleep.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 179,
              y: 14,
              src: 'phone.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 134,
              y: 14,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 145,
              month_startY: 290,
              month_sc_array: ["month_0000_de-enero.png","month_0001_de-febrero.png","month_0002_de-marzo.png","month_0003_de-abril.png","month_0004_de-mayo.png","month_0005_de-junio.png","month_0006_de-julio.png","month_0007_de-agosto.png","month_0008_de-septiembre.png","month_0009_de-octubre.png","month_0010_de-noviembre.png","month_0011_de-diciembre.png"],
              month_tc_array: ["month_0000_de-enero.png","month_0001_de-febrero.png","month_0002_de-marzo.png","month_0003_de-abril.png","month_0004_de-mayo.png","month_0005_de-junio.png","month_0006_de-julio.png","month_0007_de-agosto.png","month_0008_de-septiembre.png","month_0009_de-octubre.png","month_0010_de-noviembre.png","month_0011_de-diciembre.png"],
              month_en_array: ["month_0000_de-enero.png","month_0001_de-febrero.png","month_0002_de-marzo.png","month_0003_de-abril.png","month_0004_de-mayo.png","month_0005_de-junio.png","month_0006_de-julio.png","month_0007_de-agosto.png","month_0008_de-septiembre.png","month_0009_de-octubre.png","month_0010_de-noviembre.png","month_0011_de-diciembre.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 40,
              day_startY: 290,
              day_sc_array: ["Day0.png","Day1.png","Day2.png","Day3.png","Day4.png","Day5.png","Day6.png","Day7.png","Day8.png","Day9.png"],
              day_tc_array: ["Day0.png","Day1.png","Day2.png","Day3.png","Day4.png","Day5.png","Day6.png","Day7.png","Day8.png","Day9.png"],
              day_en_array: ["Day0.png","Day1.png","Day2.png","Day3.png","Day4.png","Day5.png","Day6.png","Day7.png","Day8.png","Day9.png"],
              day_zero: 1,
              day_space: -25,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 47,
              y: 102,
              week_en: ["dd0.png","dd1.png","dd2.png","dd3.png","dd4.png","dd5.png","dd6.png"],
              week_tc: ["dd0.png","dd1.png","dd2.png","dd3.png","dd4.png","dd5.png","dd6.png"],
              week_sc: ["dd0.png","dd1.png","dd2.png","dd3.png","dd4.png","dd5.png","dd6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 27,
              hour_startY: 188,
              hour_array: ["h_0000_0-.png","h_0001_1.png","h_0002_2.png","h_0003_3.png","h_0004_4.png","h_0005_5.png","h_0006_6.png","h_0007_7.png","h_0008_8.png","h_0009_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'separator.png',
              hour_unit_tc: 'separator.png',
              hour_unit_en: 'separator.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["m_0000_0-.png","m_0001_1.png","m_0002_2.png","m_0003_3.png","m_0004_4.png","m_0005_5.png","m_0006_6.png","m_0007_7.png","m_0008_8.png","m_0009_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              second_startX: 0,
              second_startY: 0,
              second_array: ["sn_0000_0.png","sn_0001_1.png","sn_0002_2.png","sn_0003_3.png","sn_0004_4.png","sn_0005_5.png","sn_0006_6.png","sn_0007_7.png","sn_0008_8.png","sn_0009_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 1,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 44,
              hour_startY: 189,
              hour_array: ["h_0000_0-.png","h_0001_1.png","h_0002_2.png","h_0003_3.png","h_0004_4.png","h_0005_5.png","h_0006_6.png","h_0007_7.png","h_0008_8.png","h_0009_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'separator.png',
              hour_unit_tc: 'separator.png',
              hour_unit_en: 'separator.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["m_0000_0-.png","m_0001_1.png","m_0002_2.png","m_0003_3.png","m_0004_4.png","m_0005_5.png","m_0006_6.png","m_0007_7.png","m_0008_8.png","m_0009_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 24,
              y: 185,
              w: 353,
              h: 100,
              src: 'Reveil.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 101,
              y: 54,
              w: 100,
              h: 38,
              src: 'Temperature.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {

              console.log('Weather city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 162;
                  let start_y_normal_battery = 431;
                  let lenght_ls_normal_battery = -21;
                  let line_width_ls_normal_battery = 12;
                  let color_ls_normal_battery = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = line_width_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = lenght_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    line_width_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_y_normal_battery_draw = start_y_normal_battery_draw - line_width_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}