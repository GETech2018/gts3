/*
** Facemaker bundle tool v0.0.2
* *huamiOS watchface js version v2.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_background_bg_img0 = '';
		let normal_background_bg_img1 = '';
		let normal_background_bg_img2 = '';
		let normal_anim_img4 = '';
		let normal_digital_clock_img_hour6 = '';
		let normal_digital_clock_img_minute7 = '';
		let normal_background_bg_img8 = '';
		let normal_date_current_date_monthday10 = '';
		let normal_date_current_date_month11 = '';
		let normal_date_current_date_year12 = '';
		let normal_background_bg_img13 = '';
		let normal_background_bg_img14 = '';
		let normal_step_current_text_img17 = '';
		let normal_calories_current_text_img19 = '';
		let normal_battery_image_progress_img_level21 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				let screenType = hmSetting.getScreenType();

				normal_background_bg_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 390,
					h: 450,
					src: '0002.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img1 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 369,
					y: 359,
					w: 14,
					h: 17,
					src: '0003.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img2 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 4,
					y: 359,
					w: 14,
					h: 19,
					src: '0004.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				if (screenType != hmSetting.screen_type.AOD) {
					normal_anim_img4 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
						x: 0,
						y: -9,
						anim_path: '',
						anim_prefix: '1669479580995',
						anim_ext: 'png',
						anim_fps: 20,
						anim_size: 10,
						anim_repeat: true,
						repeat_count: 0,
						anim_status: hmUI.anim_status.START,
						display_on_restart: false,
					});
				};

				normal_digital_clock_img_hour6 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 20,
					hour_startY: 99,
					hour_array: ["0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.CENTER_H,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_digital_clock_img_minute7 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 239,
					minute_startY: 32,
					minute_array: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.CENTER_H,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img8 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 178,
					y: 63,
					w: 34,
					h: 81,
					src: '0035.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_current_date_monthday10 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 81,
					day_startY: 407,
					day_sc_array: ["0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png"],
					day_tc_array: ["0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png"],
					day_en_array: ["0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png"],
					day_zero: true,
					day_space: 0,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_current_date_month11 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 149,
					month_startY: 406,
					month_sc_array: ["0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png"],
					month_tc_array: ["0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png"],
					month_en_array: ["0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png"],
					month_zero: true,
					month_space: 0,
					month_align: hmUI.align.CENTER_H,
					month_is_character: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_current_date_year12 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					year_startX: 216,
					year_startY: 406,
					year_sc_array: ["0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png"],
					year_tc_array: ["0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png"],
					year_en_array: ["0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png"],
					year_zero: true,
					year_space: 0,
					year_align: hmUI.align.CENTER_H,
					year_is_character: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img13 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 136,
					y: 405,
					w: 11,
					h: 37,
					src: '0066.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_background_bg_img14 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 202,
					y: 405,
					w: 11,
					h: 37,
					src: '0066.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_step_current_text_img17 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 30,
					y: 347,
					font_array: ["0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png"],
					padding: true,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calories_current_text_img19 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 245,
					y: 347,
					font_array: ["0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png"],
					padding: true,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_image_progress_img_level21 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 185,
					y: 351,
					image_array: ["0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png"],
					image_length: 10,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}