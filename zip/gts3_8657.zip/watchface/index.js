﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_date_img_date_day = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'IMG_8681.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 245,
              year_startY: 103,
              year_sc_array: ["000.png","001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png"],
              year_tc_array: ["000.png","001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png"],
              year_en_array: ["000.png","001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png"],
              year_zero: 0,
              year_space: 2,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 162,
              month_startY: 103,
              month_sc_array: ["000.png","001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png"],
              month_tc_array: ["000.png","001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png"],
              month_en_array: ["000.png","001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png"],
              month_zero: 1,
              month_space: 2,
              month_unit_sc: '0021.png',
              month_unit_tc: '0021.png',
              month_unit_en: '0021.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 92,
              y: 317,
              font_array: ["000.png","001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png"],
              padding: false,
              h_space: 2,
              unit_sc: '0020.png',
              unit_tc: '0020.png',
              unit_en: '0020.png',
              negative_image: '0021.png',
              invalid_image: '0021.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 222,
              y: 314,
              image_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 55,
              hour_startY: 185,
              hour_array: ["0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 221,
              minute_startY: 185,
              minute_array: ["0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 78,
              day_startY: 103,
              day_sc_array: ["000.png","001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png"],
              day_tc_array: ["000.png","001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png"],
              day_en_array: ["000.png","001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png"],
              day_zero: 1,
              day_space: 2,
              day_unit_sc: '0021.png',
              day_unit_tc: '0021.png',
              day_unit_en: '0021.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0097.png',
              hour_centerX: 195,
              hour_centerY: 225,
              hour_posX: 17,
              hour_posY: 122,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0098.png',
              minute_centerX: 195,
              minute_centerY: 225,
              minute_posX: 15,
              minute_posY: 150,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0099.png',
              second_centerX: 195,
              second_centerY: 225,
              second_posX: 5,
              second_posY: 144,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 92,
              y: 317,
              font_array: ["000.png","001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png"],
              padding: false,
              h_space: 2,
              unit_sc: '0020.png',
              unit_tc: '0020.png',
              unit_en: '0020.png',
              negative_image: '0021.png',
              invalid_image: '0021.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 222,
              y: 314,
              image_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 55,
              hour_startY: 185,
              hour_array: ["0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 221,
              minute_startY: 185,
              minute_array: ["0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  